// CRMModule.java
package com.tragofone.app;

import android.content.SharedPreferences;
import android.content.Context;
import android.util.Log;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Promise;

import android.util.Log;

public class CRMModule extends ReactContextBaseJavaModule {
    private final ReactApplicationContext mReactContext; // ✅ Store context in a class-level variable
    private static final String LANGUAGE_KEY = "_appLanguage";

    public CRMModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.mReactContext = reactContext; // ✅ Assign constructor param to class member
    }

    @Override
    public String getName() {
        return "CRMModule";
    }

    @ReactMethod
    public void setCRMData(String isEnabled, String onCallUrl, String postHangUpUrl, String userID) {
        Log.d("CRM", "CRM Config received:");
        // Log.d("CRM", "isEnabled: " + isEnabled);
        // Log.d("CRM", "onCallUrl: " + onCallUrl);
        // Log.d("CRM", "postHangUpUrl: " + postHangUpUrl);
        // Log.d("CRM", "userID: " + userID);

        SharedPreferences prefs = mReactContext.getSharedPreferences("CRM_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("_isCRMEnabled", isEnabled);
        editor.putString("_crmOnCallUrl", onCallUrl);
        editor.putString("_crmPostHangUpUrl", postHangUpUrl);
        editor.putString("_crmUserID", userID);

        editor.apply();
    }

    @ReactMethod
    public void clearCRMData() {
        Log.d("CRM", "Clearing CRM data...");

        SharedPreferences prefs = mReactContext.getSharedPreferences("CRM_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.remove("_isCRMEnabled");
        editor.remove("_crmOnCallUrl");
        editor.remove("_crmPostHangUpUrl");
        editor.remove("_crmUserID");

        editor.apply();
    }

        // 🔤 LANGUAGE METHODS

    @ReactMethod
    public void setAppLanguage(String languageCode) {
        Log.d("CRM", "Setting language: " + languageCode);

        SharedPreferences prefs = mReactContext.getSharedPreferences(LANGUAGE_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString(LANGUAGE_KEY, languageCode);
        editor.apply();
    }

    @ReactMethod
    public void getAppLanguage(Promise promise) {
        try {
            SharedPreferences prefs = mReactContext.getSharedPreferences(LANGUAGE_KEY, Context.MODE_PRIVATE);
            String language = prefs.getString(LANGUAGE_KEY, "en"); // fallback to "en"
            promise.resolve(language);
        } catch (Exception e) {
            Log.e("CRM", "Failed to get language", e);
            promise.reject("GET_LANGUAGE_ERROR", e);
        }
    }

    @ReactMethod
    public void clearAppLanguage() {
        Log.d("CRM", "Clearing app language");

        SharedPreferences prefs = mReactContext.getSharedPreferences(LANGUAGE_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.remove(LANGUAGE_KEY);
        editor.apply();
    }

    // 📞 CALL SESSION METHODS

    @ReactMethod
    public void saveCallToken(String callToken) {
        Log.d("CRM", "Saving call token: " + callToken);

        SharedPreferences prefs = mReactContext.getSharedPreferences("CALL_TOKEN_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("_currentCallToken", callToken);
        editor.putLong("_tokenTimestamp", System.currentTimeMillis());

        editor.apply();
    }

    @ReactMethod
    public void clearCallToken() {
        Log.d("CRM", "Clearing call token");

        SharedPreferences prefs = mReactContext.getSharedPreferences("CALL_TOKEN_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.remove("_currentCallToken");
        editor.remove("_tokenTimestamp");

        editor.apply();
    }

    @ReactMethod
    public void saveCallCount(int callCount) {
        Log.d("CRM", "Saving call count: " + callCount);

        SharedPreferences prefs = mReactContext.getSharedPreferences("CALL_COUNT_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putInt("_currentCallCount", callCount);
        editor.putLong("_countTimestamp", System.currentTimeMillis());

        editor.apply();
    }

    @ReactMethod
    public void clearCallCount() {
        Log.d("CRM", "Clearing call count");

        SharedPreferences prefs = mReactContext.getSharedPreferences("CALL_COUNT_PREFS", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.remove("_currentCallCount");
        editor.remove("_countTimestamp");

        editor.apply();
    }

}
