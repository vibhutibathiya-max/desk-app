package com.tragofone.app; // Replace with your actual package

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.media.MediaPlayer;
import androidx.annotation.Nullable;
import android.os.Vibrator;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import androidx.core.app.ActivityCompat;
import android.os.VibrationEffect;
import android.os.VibrationAttributes;
import android.os.PowerManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import android.app.PendingIntent;
import com.tragofone.app.FileLoggerHelper;


public class RingtoneService extends Service {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private boolean isNativeCallActive = false;
    private boolean isStopped = false;
    private Handler vibrationHandler;
    private Runnable vibrationRunnable;
    private PowerManager.WakeLock serviceWakeLock;
    private static final String NOTIFICATION_CHANNEL_ID = "RingtoneServiceChannel";
    private static final int NOTIFICATION_ID = 1001;
    
    // Notification data for incoming call
    private String notificationData;
    private String callerNumber;
    private String callerName;
    private String callerProfilePic;
    private String notificationUuid;
    
    private final BroadcastReceiver screenOffReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                stopRinging();
            }
        }
    };

    private final BroadcastReceiver customStopReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("com.tragofone.app.ACTION_STOP_RINGING".equals(intent.getAction())) {
                stopRinging();
            }
        }
    };


    @Override
    public void onCreate() {
        super.onCreate();
        
        // Configure file logger to write to the same file as React Native logs
        FileLoggerHelper.configure(this);
        
        FileLoggerHelper.info("RingtoneService", "🔔 RingtoneService created - Initializing service components");
        
        registerReceiver(screenOffReceiver, new IntentFilter(Intent.ACTION_SCREEN_OFF), Context.RECEIVER_NOT_EXPORTED);

        IntentFilter stopRingingFilter = new IntentFilter("com.tragofone.app.ACTION_STOP_RINGING");
        registerReceiver(customStopReceiver, stopRingingFilter, Context.RECEIVER_NOT_EXPORTED);

        // Initialize TelephonyManager to detect native call state
        initializePhoneStateListener();

        FileLoggerHelper.debug("RingtoneService", "✅ Service initialization completed - Receivers registered, phone state listener initialized");

    }

    private void initializePhoneStateListener() {
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        
        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String phoneNumber) {
                switch (state) {
                    case TelephonyManager.CALL_STATE_IDLE:
                        Log.d("CallState", "CALL_STATE_IDLE - No call");
                        isNativeCallActive = false;
                        break;
                    case TelephonyManager.CALL_STATE_RINGING:
                        Log.d("CallState", "CALL_STATE_RINGING - Incoming call from: " + phoneNumber);
                        isNativeCallActive = false;
                        break;
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        Log.d("CallState", "CALL_STATE_OFFHOOK - Call is active or outgoing");
                        isNativeCallActive = true;
                        break;
                }
                Log.d("RingtoneService", "Native call active: " + isNativeCallActive);
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
            Log.d("RingtoneService", "Phone state listener registered");
            
            // Check current call state immediately
            int currentCallState = telephonyManager.getCallState();
            Log.d("RingtoneService", "Current call state: " + currentCallState);
            isNativeCallActive = (currentCallState == TelephonyManager.CALL_STATE_OFFHOOK);
            Log.d("RingtoneService", "Initial native call active: " + isNativeCallActive);
        } else {
            Log.w("RingtoneService", "READ_PHONE_STATE permission not granted");
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        FileLoggerHelper.info("RingtoneService", "🔔 RingtoneService started - App foreground state: " + isAppOnForeground());
        
        // Extract notification data from intent
        if (intent != null) {
            notificationData = intent.getStringExtra("notification_data");
            callerNumber = intent.getStringExtra("caller_number");
            callerName = intent.getStringExtra("caller_name");
            callerProfilePic = intent.getStringExtra("caller_profilePic");
            notificationUuid = intent.getStringExtra("notification_uuid");
            
            FileLoggerHelper.info("RingtoneService", "📞 Incoming call from: " + callerName + " (" + callerNumber + ")");
            FileLoggerHelper.debug("RingtoneService", "📱 Notification UUID: " + notificationUuid);
            FileLoggerHelper.debug("RingtoneService", "📱 Profile pic: " + (callerProfilePic != null ? "provided" : "not provided"));
        } else {
            FileLoggerHelper.warn("RingtoneService", "⚠️ onStartCommand called with null intent");
        }
        
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            FileLoggerHelper.warn("RingtoneService", "⚠️ Service already playing ringtone, returning START_STICKY");
            return START_STICKY;
        }

        // Start as foreground service with proper notification
        FileLoggerHelper.debug("RingtoneService", "🚀 Starting foreground service with notification");
        startForegroundService();
        
        // Start ringtone/vibration playback
        // This will work when not restricted. When restricted, notification sound/vibration will handle it
        FileLoggerHelper.info("RingtoneService", "🎵 Starting ringtone/vibration playback");
        playRingtone(getApplicationContext());
        
        // IMPORTANT: Even if startForeground() was blocked, the service continues running
        // The wake lock keeps it alive, and playRingtone() will attempt to play audio/vibrate
        // If MediaPlayer/Vibrator are blocked, the notification system will handle sound/vibration
        
        return START_STICKY;
    }

    private boolean isAppOnForeground() {
        try {
            android.app.ActivityManager activityManager = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            java.util.List<android.app.ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
            if (appProcesses == null) {
                return false;
            }
            final String packageName = getPackageName();
            for (android.app.ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
                if (appProcess.importance == android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND &&
                    appProcess.processName.equals(packageName)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            Log.e("RingtoneService", "Error checking foreground state", e);
            return false;
        }
    }

    private void startForegroundService() {
        createNotificationChannel();
        
        // Always create incoming call notification as foreground service
        Notification notification = createIncomingCallNotification();
        if (notification != null) {
            // CRITICAL: Always show notification via NotificationManager first
            // This ensures notification is displayed even when startForeground() is blocked
            // Android may block startForeground() silently without throwing an exception
            try {
                NotificationManager notificationManager = getSystemService(NotificationManager.class);
                if (notificationManager != null) {
                    notificationManager.notify(NOTIFICATION_ID, notification);
                    Log.d("RingtoneService", "✅ Notification shown via NotificationManager (ensures visibility even if foreground blocked)");
                    FileLoggerHelper.info("RingtoneService", "✅ Notification displayed via NotificationManager");
                }
            } catch (Exception e) {
                Log.e("RingtoneService", "❌ Failed to show notification via NotificationManager: " + e.getMessage());
            }
            
            // Try to start as foreground service (may be blocked by battery restrictions)
            // Even if blocked, we continue - notification is already shown
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    // Android 14+ (API 34+) requires service type parameter
                    startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL);
                } else {
                    // Android 13 and below
                    startForeground(NOTIFICATION_ID, notification);
                }
                Log.d("RingtoneService", "🔔 Started as foreground service with incoming call notification");
                FileLoggerHelper.info("RingtoneService", "🔔 Foreground service started successfully");
            } catch (Exception e) {
                // startForeground() might fail due to background restrictions
                Log.w("RingtoneService", "⚠️ startForeground() failed (may be due to battery restrictions): " + e.getMessage());
                FileLoggerHelper.warn("RingtoneService", "⚠️ startForeground() blocked - continuing with notification already shown");
            }
            
            // Acquire wake lock to keep service alive even if foreground is blocked
            // This helps ensure ringtone/vibration can still work
            try {
                PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (powerManager != null) {
                    serviceWakeLock = powerManager.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK,
                        "RingtoneService:KeepAlive"
                    );
                    serviceWakeLock.acquire(5 * 60 * 1000L); // 5 minutes
                    Log.d("RingtoneService", "✅ WakeLock acquired to keep service alive");
                    FileLoggerHelper.debug("RingtoneService", "✅ Service WakeLock acquired");
                }
            } catch (Exception e) {
                Log.w("RingtoneService", "⚠️ Failed to acquire service WakeLock: " + e.getMessage());
                // Continue anyway - notification is shown
            }
        } else {
            Log.e("RingtoneService", "❌ Failed to create notification - service cannot start");
            FileLoggerHelper.error("RingtoneService", "❌ Failed to create notification");
            // This should not happen - if it does, there's a serious issue
            throw new RuntimeException("Failed to create incoming call notification");
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;
            
            // Get or create the main call channel with sound and vibration enabled
            // This ensures sound/vibration work even when service is restricted
            NotificationChannel callChannel = manager.getNotificationChannel("call_channel_id");
            
            if (callChannel == null) {
                // Channel doesn't exist, create it WITHOUT sound but WITH vibration
                // IMPORTANT: Sound is handled by MediaPlayer in playRingtone() for dynamic tone switching
                // (default ringtone vs custom ziptone based on call count)
                // BUT vibration is enabled on channel to work when battery restricted
                callChannel = new NotificationChannel(
                        "call_channel_id",
                        "Incoming Calls",
                        NotificationManager.IMPORTANCE_HIGH
                );
                callChannel.setDescription("Incoming call alerts");
                callChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                callChannel.setShowBadge(false);
                
                // NO SOUND on channel - MediaPlayer handles audio for dynamic tone switching
                callChannel.setSound(null, null);
                // ENABLE vibration on channel - this works even when foreground service is blocked by battery restrictions
                callChannel.enableVibration(true);
                callChannel.setVibrationPattern(new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000}); // vibrate pattern for incoming call
                
                manager.createNotificationChannel(callChannel);
                Log.d("RingtoneService", "✅ Created call channel (NO sound, WITH vibration for battery-restricted mode)");
            } else {
                // Channel already exists - DON'T recreate it!
                // IncomingCallNotificationManager already created it with correct settings.
                // Recreating the channel while notification is active breaks vibration.
                // Only check if sound needs to be disabled (legacy upgrade case)
                if (callChannel.getSound() != null) {
                    Log.w("RingtoneService", "⚠️ Existing channel has sound enabled - deleting to recreate");
                    try {
                        manager.deleteNotificationChannel("call_channel_id");
                        Log.d("RingtoneService", "✅ Deleted old call channel with sound");
                        
                        // Recreate WITHOUT sound but WITH vibration
                        callChannel = new NotificationChannel(
                                "call_channel_id",
                                "Incoming Calls",
                                NotificationManager.IMPORTANCE_HIGH
                        );
                        callChannel.setDescription("Incoming call alerts");
                        callChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                        callChannel.setShowBadge(false);
                        
                        // NO SOUND - MediaPlayer handles audio
                        callChannel.setSound(null, null);
                        // ENABLE vibration - works even when battery restricted
                        callChannel.enableVibration(true);
                        callChannel.setVibrationPattern(new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000});
                        
                        manager.createNotificationChannel(callChannel);
                        Log.d("RingtoneService", "✅ Recreated call channel (NO sound, WITH vibration)");
                    } catch (Exception e) {
                        Log.e("RingtoneService", "❌ Failed to recreate channel: " + e.getMessage());
                    }
                } else {
                    // Channel exists without sound - don't touch it!
                    // Vibration setting is controlled by channel + notification vibrate pattern
                    Log.d("RingtoneService", "✅ Call channel exists (no sound) - not modifying to preserve vibration");
                }
            }
            
            // Create the service channel (silent, for foreground service notification)
            NotificationChannel serviceChannel = manager.getNotificationChannel(NOTIFICATION_CHANNEL_ID);
            if (serviceChannel == null) {
                serviceChannel = new NotificationChannel(
                        NOTIFICATION_CHANNEL_ID,
                        "Ringtone Service",
                        NotificationManager.IMPORTANCE_HIGH
                );
                serviceChannel.setDescription("Service for playing incoming call ringtones");
                serviceChannel.setShowBadge(false);
                serviceChannel.setSound(null, null);
                serviceChannel.enableVibration(false);
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    @Override
    public void onDestroy() {
        Log.d("RingtoneService", "onDestroy() called");
        unregisterReceiver(screenOffReceiver);
        unregisterReceiver(customStopReceiver);
        
        // Unregister phone state listener
        if (telephonyManager != null && phoneStateListener != null) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        }
        
        // Release wake lock if acquired
        if (serviceWakeLock != null && serviceWakeLock.isHeld()) {
            try {
                serviceWakeLock.release();
                Log.d("RingtoneService", "✅ Service WakeLock released");
            } catch (Exception e) {
                Log.w("RingtoneService", "⚠️ Error releasing WakeLock: " + e.getMessage());
            }
            serviceWakeLock = null;
        }
        
        // Ensure vibration is stopped
        stopManualVibrationLoop();
        
        stopRinging();
        super.onDestroy();
    }

    public void playRingtone(Context context) {
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int ringerMode = audioManager.getRingerMode();

        // Read call count from SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("CALL_COUNT_PREFS", Context.MODE_PRIVATE);
        int callCount = prefs.getInt("_currentCallCount", 0);
        
        FileLoggerHelper.debug("RingtoneService", "📊 Call state - Count: " + callCount + ", Native active: " + isNativeCallActive + ", Ringer: " + ringerMode + " (0=SILENT, 1=VIBRATE, 2=NORMAL)");

        switch (ringerMode) {
            case AudioManager.RINGER_MODE_SILENT:
                // 🔇 Silent mode: Do nothing
                FileLoggerHelper.info("RingtoneService", "🔇 Device in SILENT mode - no ringtone or vibration");
                break;

            case AudioManager.RINGER_MODE_VIBRATE:
                // 🔕 Vibrate only
                FileLoggerHelper.info("RingtoneService", "🔕 Device in VIBRATE mode - starting vibration only");
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startContinuousVibration(context);
                    }
                }, 500); // 500ms delay
                break;
            case AudioManager.RINGER_MODE_NORMAL:
                // 🔊 Normal mode: Play ringtone
                FileLoggerHelper.info("RingtoneService", "🔊 Device in NORMAL mode - starting ringtone playback");
                
                // Use different methods for default vs custom ringtone
                if (isNativeCallActive || callCount >= 1) {
                    // Play custom ziptone with gaps
                    FileLoggerHelper.debug("RingtoneService", "🎵 Playing custom ziptone (call count: " + callCount + ", native active: " + isNativeCallActive + ")");
                    playCustomZiptone(context, audioManager);
                } else {
                    // Play default system ringtone
                    FileLoggerHelper.debug("RingtoneService", "🎵 Playing default system ringtone");
                    playDefaultRingtone(context, audioManager);
                }
                break;
        }
    }

    private void startContinuousVibration(Context context) {
        Log.d("RingtoneService", "🔔 startContinuousVibration called");
        // Stop any existing vibration first to prevent multiple loops
        stopManualVibrationLoop();
        
        final Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) {
            Log.w("RingtoneService", "Vibrator is null or not available");
            return;
        }
        
        Log.d("RingtoneService", "🔔 Starting continuous vibration");

        final long[] pattern = {0, 1000, 1000}; // vibrate 1s, pause 1s

        vibrationHandler = new Handler(Looper.getMainLooper());
        vibrationRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isStopped) {
                    safeVibrate(context, pattern); // works on all devices
                    long totalDuration = 0;
                    for (long l : pattern) totalDuration += l;
                    vibrationHandler.postDelayed(this, totalDuration);
                }
            }
        };
        vibrationHandler.post(vibrationRunnable);
    }

    private void stopContinuousVibration() {
        if (vibrationHandler != null && vibrationRunnable != null) {
            vibrationHandler.removeCallbacks(vibrationRunnable);
            vibrationHandler = null;
            vibrationRunnable = null;
        }
    }

    private void safeVibrate(Context context, long[] pattern) {
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        if (vibrator != null && vibrator.hasVibrator()) {
            AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            int ringerMode = audioManager.getRingerMode();
            
            if (ringerMode == AudioManager.RINGER_MODE_VIBRATE ||
                ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                
                // Android 13+ (API 33+): Try VibrationAttributes with USAGE_ALARM for highest priority
                // This bypasses battery restrictions as alarms are exempt
                // IMPORTANT: Some OEM devices (Oppo, Xiaomi, etc.) don't implement this method
                // even on API 33+, so we catch NoSuchMethodError explicitly
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // API 33
                    try {
                        VibrationEffect effect = VibrationEffect.createWaveform(pattern, -1); // -1 = don't repeat
                        VibrationAttributes attrs = new VibrationAttributes.Builder()
                                .setUsage(VibrationAttributes.USAGE_ALARM) // USAGE_ALARM bypasses battery restrictions
                                .build();
                        vibrator.vibrate(effect, attrs);
                        Log.d("RingtoneService", "✅ Vibration triggered with VibrationAttributes USAGE_ALARM (Android 13+)");
                        return; // Success, exit early
                    } catch (NoSuchMethodError e) {
                        // Some OEM devices don't implement vibrate(VibrationEffect, VibrationAttributes)
                        Log.w("RingtoneService", "⚠️ VibrationAttributes not supported on this device (NoSuchMethodError), using fallback");
                    } catch (Exception e) {
                        Log.e("RingtoneService", "❌ VibrationAttributes failed: " + e.getMessage());
                    }
                    // Fallback to simpler API
                    tryVibrationWithEffect(pattern);
                }
                // Android 11-12 (API 30-32): Try VibrationAttributes with USAGE_RINGTONE
                // IMPORTANT: Oppo Android 11 and other OEMs may crash with NoSuchMethodError
                else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { // API 30
                    try {
                        VibrationEffect effect = VibrationEffect.createWaveform(pattern, -1);
                        VibrationAttributes attrs = new VibrationAttributes.Builder()
                                .setUsage(VibrationAttributes.USAGE_RINGTONE) // USAGE_RINGTONE for incoming calls
                                .build();
                        vibrator.vibrate(effect, attrs);
                        Log.d("RingtoneService", "✅ Vibration triggered with VibrationAttributes USAGE_RINGTONE (Android 11-12)");
                        return; // Success, exit early
                    } catch (NoSuchMethodError e) {
                        // Oppo, Xiaomi, and other OEM devices may not implement this method
                        Log.w("RingtoneService", "⚠️ VibrationAttributes not supported on this device (NoSuchMethodError), using fallback");
                    } catch (Exception e) {
                        Log.e("RingtoneService", "❌ VibrationAttributes failed: " + e.getMessage());
                    }
                    // Fallback to simpler API without attributes
                    tryVibrationWithEffect(pattern);
                }
                // Android 8.0-10 (API 26-29): Use VibrationEffect without attributes
                else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { // API 26
                    tryVibrationWithEffect(pattern);
                } else {
                    // Android 7.1 and below: Use legacy API
                    tryVibrationLegacy(pattern);
                }
            }
        }
    }
    
    // VibrationEffect API (Android 8.0+) - without VibrationAttributes
    private void tryVibrationWithEffect(long[] pattern) {
        try {
            if (vibrator != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                VibrationEffect effect = VibrationEffect.createWaveform(pattern, -1);
                vibrator.vibrate(effect);
                Log.d("RingtoneService", "✅ Vibration triggered with VibrationEffect (no attributes)");
            } else {
                tryVibrationLegacy(pattern);
            }
        } catch (Exception e) {
            Log.e("RingtoneService", "❌ VibrationEffect failed: " + e.getMessage());
            tryVibrationLegacy(pattern);
        }
    }
    
    // Legacy vibration API (all Android versions)
    private void tryVibrationLegacy(long[] pattern) {
        try {
            if (vibrator != null) {
                vibrator.vibrate(pattern, -1); // -1 = don't repeat
                Log.d("RingtoneService", "✅ Vibration triggered with legacy API");
            }
        } catch (Exception e) {
            Log.e("RingtoneService", "❌ Legacy vibration also failed: " + e.getMessage());
        }
    }

    private void stopRinging() {
        FileLoggerHelper.info("RingtoneService", "🛑 Stopping ringtone service");
        isStopped = true; // Set flag to stop restarting
        
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                FileLoggerHelper.debug("RingtoneService", "🔇 Stopping media player");
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }

        // Stop vibration
        FileLoggerHelper.debug("RingtoneService", "🔇 Stopping vibration");
        stopManualVibrationLoop();

        FileLoggerHelper.info("RingtoneService", "✅ Ringtone service stopped successfully");
        stopSelf();
    }

    // Method to play default system ringtone
    private void playDefaultRingtone(Context context, AudioManager audioManager) {
        try {
            Log.d("RingtoneService", "🔔 Playing default system ringtone");
            
            Uri ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            Log.d("RingtoneService", "Default ringtone URI: " + ringtoneUri);
            
            // Ensure appropriate volume
            ensureAppropriateRingVolume(audioManager);
            
            // Try to request audio focus, but don't fail if denied
            int audioFocusResult = audioManager.requestAudioFocus(
                new AudioManager.OnAudioFocusChangeListener() {
                    @Override
                    public void onAudioFocusChange(int focusChange) {
                        Log.d("RingtoneService", "Audio focus changed: " + focusChange);
                        if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                            stopRinging();
                        }
                    }
                },
                AudioManager.STREAM_RING,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            );
            
            Log.d("RingtoneService", "Audio focus request result: " + audioFocusResult);
            
            // Play ringtone regardless of audio focus result
            // Ringtones should play even without audio focus for incoming calls
            try {
                // Create MediaPlayer for default ringtone
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, ringtoneUri);
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_RING);
                mediaPlayer.setLooping(true); // Loop continuously for default ringtone
                
                // Set volume to maximum for ringtone
                mediaPlayer.setVolume(1.0f, 1.0f);
                
                // Add error listener to detect playback issues
                mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.e("RingtoneService", "❌ MediaPlayer error - what: " + what + ", extra: " + extra);
                        return false;
                    }
                });
                
                // Add info listener to get playback status
                mediaPlayer.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                    @Override
                    public boolean onInfo(MediaPlayer mp, int what, int extra) {
                        Log.d("RingtoneService", "ℹ️ MediaPlayer info - what: " + what + ", extra: " + extra);
                        return false;
                    }
                });
                
                // Prepare and start
                mediaPlayer.prepare();
                mediaPlayer.start();
                
                if (audioFocusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    Log.d("RingtoneService", "✅ Default ringtone started successfully with audio focus");
                } else {
                    Log.d("RingtoneService", "✅ Default ringtone started successfully without audio focus");
                }
                
            } catch (Exception e) {
                Log.e("RingtoneService", "❌ Error creating MediaPlayer for default ringtone: " + e.getMessage());
                // Try with different stream type as fallback
                tryDifferentStreamTypesForDefault(context, ringtoneUri, audioManager);
            }
            
        } catch (Exception e) {
            Log.e("RingtoneService", "❌ Error playing default ringtone: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Method to play custom ziptone with gaps
    private void playCustomZiptone(Context context, AudioManager audioManager) {
        try {
            Log.d("RingtoneService", "🔔 Playing custom ziptone with gaps");
            
            // Try different possible paths for ziptone
            Uri ringtoneUri = null;
            String[] possiblePaths = {
                "android.resource://" + getPackageName() + "/raw/ziptone",
                "android.resource://" + getPackageName() + "/raw/ziptone.mp3",
                "android.resource://" + getPackageName() + "/raw/ziptone.wav"
            };
            
            // Test which path works
            for (String path : possiblePaths) {
                try {
                    Uri testUri = Uri.parse(path);
                    MediaPlayer testPlayer = new MediaPlayer();
                    testPlayer.setDataSource(context, testUri);
                    testPlayer.prepare();
                    testPlayer.release();
                    ringtoneUri = testUri;
                    Log.d("RingtoneService", "✅ Found ziptone at: " + path);
                    break;
                } catch (Exception e) {
                    Log.d("RingtoneService", "❌ Path not found: " + path);
                }
            }
            
            if (ringtoneUri == null) {
                Log.e("RingtoneService", "❌ Ziptone file not found, falling back to default ringtone");
                playDefaultRingtone(context, audioManager);
                return;
            }
            
            // Ensure appropriate volume
            ensureAppropriateRingVolume(audioManager);
            
            // Request audio focus with different strategies for ziptone
            int audioFocusResult = audioManager.requestAudioFocus(
                new AudioManager.OnAudioFocusChangeListener() {
                    @Override
                    public void onAudioFocusChange(int focusChange) {
                        Log.d("RingtoneService", "Audio focus changed: " + focusChange);
                        if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                            stopRinging();
                        }
                    }
                },
                AudioManager.STREAM_RING,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            );
            
            Log.d("RingtoneService", "Audio focus request result for ziptone: " + audioFocusResult);
            Log.d("RingtoneService", "🎯 AUDIO FOCUS ATTEMPT 1: GAIN_TRANSIENT_MAY_DUCK + STREAM_RING = " + audioFocusResult);
            
            // If first attempt fails, try with different focus type
            if (audioFocusResult != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                Log.d("RingtoneService", "First audio focus request failed, trying with GAIN_TRANSIENT");
                audioFocusResult = audioManager.requestAudioFocus(
                    new AudioManager.OnAudioFocusChangeListener() {
                        @Override
                        public void onAudioFocusChange(int focusChange) {
                            Log.d("RingtoneService", "Audio focus changed: " + focusChange);
                            if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                                stopRinging();
                            }
                        }
                    },
                    AudioManager.STREAM_RING,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                );
                Log.d("RingtoneService", "Second audio focus request result: " + audioFocusResult);
                Log.d("RingtoneService", "🎯 AUDIO FOCUS ATTEMPT 2: GAIN_TRANSIENT + STREAM_RING = " + audioFocusResult);
            }
            
            // Track which stream type was used
            int usedStreamType = AudioManager.STREAM_RING;
            
            // If still fails, try with different stream type
            if (audioFocusResult != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                Log.d("RingtoneService", "Ring stream failed, trying with MUSIC stream");
                audioFocusResult = audioManager.requestAudioFocus(
                    new AudioManager.OnAudioFocusChangeListener() {
                        @Override
                        public void onAudioFocusChange(int focusChange) {
                            Log.d("RingtoneService", "Audio focus changed: " + focusChange);
                            if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                                stopRinging();
                            }
                        }
                    },
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                );
                Log.d("RingtoneService", "Music stream audio focus request result: " + audioFocusResult);
                Log.d("RingtoneService", "🎯 AUDIO FOCUS ATTEMPT 3: GAIN_TRANSIENT + STREAM_MUSIC = " + audioFocusResult);
                if (audioFocusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    usedStreamType = AudioManager.STREAM_MUSIC;
                }
            }
            
            // Play ziptone regardless of audio focus result
            // Ringtones should play even without audio focus for incoming calls
            try {
                // Create MediaPlayer for ziptone
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, ringtoneUri);
                mediaPlayer.setAudioStreamType(usedStreamType);
                Log.d("RingtoneService", "Using audio stream type: " + usedStreamType);
                
                // Set volume to maximum for ziptone
                mediaPlayer.setVolume(1.0f, 1.0f);
                Log.d("RingtoneService", "🔊 Set ziptone volume to maximum (1.0f, 1.0f)");
                
                // Log current audio settings
                int currentRingVolume = audioManager.getStreamVolume(AudioManager.STREAM_RING);
                int maxRingVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING);
                int currentMusicVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                int maxMusicVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                Log.d("RingtoneService", "📊 Ring volume: " + currentRingVolume + "/" + maxRingVolume);
                Log.d("RingtoneService", "📊 Music volume: " + currentMusicVolume + "/" + maxMusicVolume);
                Log.d("RingtoneService", "📊 Ringer mode: " + audioManager.getRingerMode());
                
                mediaPlayer.setLooping(false); // Don't loop, we'll handle it manually
                
                // Make ringtoneUri final for inner class access
                final Uri finalRingtoneUri = ringtoneUri;
                
                // Set completion listener for ziptone with gaps
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        if (!isStopped) {
                            // Wait for gap then restart
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (!isStopped) {
                                        restartZiptoneWithGap(context, finalRingtoneUri);
                                    }
                                }
                            }, 2000); // 2 second gap
                        }
                    }
                });
                
                // Prepare and start
                mediaPlayer.prepare();
                mediaPlayer.start();
                
                if (audioFocusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    Log.d("RingtoneService", "✅ Custom ziptone started successfully with AUDIO FOCUS");
                    Log.d("RingtoneService", "🎯 SUCCESS PATH: playCustomZiptone() -> Audio Focus Granted");
                } else {
                    Log.d("RingtoneService", "✅ Custom ziptone started successfully WITHOUT AUDIO FOCUS");
                    Log.d("RingtoneService", "🎯 SUCCESS PATH: playCustomZiptone() -> No Audio Focus");
                }
                Log.d("RingtoneService", "🎯 STREAM TYPE: " + usedStreamType + " (1=RING, 3=MUSIC)");
                
            } catch (Exception e) {
                Log.e("RingtoneService", "❌ Error creating MediaPlayer for ziptone: " + e.getMessage());
                // Try with different stream types as fallback
                tryDifferentStreamTypes(context, ringtoneUri, audioManager);
            }
            
            
        } catch (Exception e) {
            Log.e("RingtoneService", "❌ Error playing custom ziptone: " + e.getMessage());
            e.printStackTrace();
            // Fallback to default ringtone
            Log.d("RingtoneService", "🔄 Falling back to default ringtone");
            playDefaultRingtone(context, audioManager);
        }
    }
    
    // Method to try different audio stream types for default ringtone
    private void tryDifferentStreamTypesForDefault(Context context, Uri ringtoneUri, AudioManager audioManager) {
        int[] streamTypes = {
            AudioManager.STREAM_RING,
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_NOTIFICATION,
            AudioManager.STREAM_ALARM
        };
        
        for (int streamType : streamTypes) {
            try {
                Log.d("RingtoneService", "🔄 Trying default ringtone with stream type: " + streamType);
                
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }
                
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, ringtoneUri);
                mediaPlayer.setAudioStreamType(streamType);
                mediaPlayer.setVolume(1.0f, 1.0f);
                mediaPlayer.setLooping(true);
                
                mediaPlayer.prepare();
                mediaPlayer.start();
                Log.d("RingtoneService", "✅ Default ringtone started successfully with stream type: " + streamType);
                return; // Success, exit the method
                
            } catch (Exception e) {
                Log.e("RingtoneService", "❌ Failed with stream type " + streamType + ": " + e.getMessage());
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            }
        }
        
        Log.e("RingtoneService", "❌ All stream types failed for default ringtone");
    }
    
    // Method to try different audio stream types for ziptone
    private void tryDifferentStreamTypes(Context context, Uri ringtoneUri, AudioManager audioManager) {
        int[] streamTypes = {
            AudioManager.STREAM_RING,
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_NOTIFICATION,
            AudioManager.STREAM_ALARM
        };
        
        for (int streamType : streamTypes) {
            try {
                Log.d("RingtoneService", "🔄 Trying ziptone with stream type: " + streamType);
                
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }
                
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, ringtoneUri);
                mediaPlayer.setAudioStreamType(streamType);
                mediaPlayer.setVolume(1.0f, 1.0f);
                mediaPlayer.setLooping(false);
                
                // Set completion listener
                final Uri finalRingtoneUri = ringtoneUri;
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        if (!isStopped) {
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (!isStopped) {
                                        restartZiptoneWithGap(context, finalRingtoneUri);
                                    }
                                }
                            }, 2000);
                        }
                    }
                });
                
                mediaPlayer.prepare();
                mediaPlayer.start();
                Log.d("RingtoneService", "✅ Ziptone started successfully with stream type: " + streamType);
                Log.d("RingtoneService", "🎯 SUCCESS PATH: tryDifferentStreamTypes() -> Stream Type " + streamType);
                Log.d("RingtoneService", "🎯 STREAM TYPE: " + streamType + " (1=RING, 3=MUSIC, 5=NOTIFICATION, 4=ALARM)");
                return; // Success, exit the method
                
            } catch (Exception e) {
                Log.e("RingtoneService", "❌ Failed with stream type " + streamType + ": " + e.getMessage());
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            }
        }
        
        // If all stream types failed, fallback to default ringtone
        Log.d("RingtoneService", "🔄 All stream types failed, falling back to default ringtone");
        playDefaultRingtone(context, audioManager);
    }
    
    // Create incoming call notification for foreground service
    private Notification createIncomingCallNotification() {
        try {
            // Ensure we have required data - provide defaults if missing
            if (callerNumber == null || callerNumber.isEmpty()) {
                callerNumber = "Unknown Caller";
                Log.w("RingtoneService", "⚠️ Missing caller number, using default");
            }
            
            if (notificationData == null) {
                notificationData = "{}";
                Log.w("RingtoneService", "⚠️ Missing notification data, using empty JSON");
            }
            
            if (notificationUuid == null) {
                notificationUuid = "";
                Log.w("RingtoneService", "⚠️ Missing notification UUID");
            }
            
            // Parse notification data to check if it's a video call
            boolean isVideo = false;
            String sipDisplayName = "";
            if (notificationData != null) {
                try {
                    JSONObject data = new JSONObject(notificationData);
                    String isVideoRaw = data.optString("is_video", "'false'");
                    isVideo = "true".equalsIgnoreCase(isVideoRaw.replace("'", "").trim());
                } catch (JSONException e) {
                    Log.e("RingtoneService", "❌ Error parsing notification data for is_video", e);
                }
                
                try {
                    JSONObject data = new JSONObject(notificationData);
                    sipDisplayName = data.optString("from_name", "");
                } catch (JSONException e) {
                    Log.e("RingtoneService", "❌ Error parsing notification data for from_name", e);
                }
            }

            if (callerName == null || callerName.isEmpty()) {
                if (sipDisplayName != null && !sipDisplayName.isEmpty()) {
                    callerName = sipDisplayName;
                    Log.w("RingtoneService", "⚠️ Missing caller name, using SIP display name");
                } else {
                    callerName = callerNumber;
                    Log.w("RingtoneService", "⚠️ Missing caller name, using number");
                }
            }

            // Get localized strings
            SharedPreferences prefs = getSharedPreferences("_appLanguage", Context.MODE_PRIVATE);
            String langCode = prefs.getString("_appLanguage", "en");
            String accept = getLocalizedString(langCode, "accept_call");
            String decline = getLocalizedString(langCode, "decline_call");
            String acceptVideo = getLocalizedString(langCode, "accept_video_call");

            // Create intents
            Intent fullScreenIntent = new Intent(this, Class.forName("com.tragofone.app.IncomingCallActivity"));
            fullScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            fullScreenIntent.putExtra("notification_data", notificationData);
            fullScreenIntent.putExtra("caller_name", callerName);
            fullScreenIntent.putExtra("caller_number", callerNumber);
            fullScreenIntent.putExtra("caller_profilePic", callerProfilePic);
            fullScreenIntent.putExtra("notification_uuid", notificationUuid);

            PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
                this, 0, fullScreenIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Accept call action
            Intent acceptIntent = new Intent(this, Class.forName("com.tragofone.app.MainActivity"));
            acceptIntent.putExtra("notification_data", notificationData);
            acceptIntent.putExtra("call_action", "accept_audio");
            acceptIntent.setAction("accept_audio");
            acceptIntent.setPackage(getPackageName());
            PendingIntent acceptPendingIntent = PendingIntent.getActivity(
                this, 1, acceptIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Accept video call action (only if is_video is true)
            PendingIntent acceptVideoPendingIntent = null;
            if (isVideo) {
                Intent acceptVideoIntent = new Intent(this, Class.forName("com.tragofone.app.MainActivity"));
                acceptVideoIntent.putExtra("notification_data", notificationData);
                acceptVideoIntent.putExtra("call_action", "accept_video");
                acceptVideoIntent.setAction("accept_video");
                acceptVideoIntent.setPackage(getPackageName());
                acceptVideoPendingIntent = PendingIntent.getActivity(
                    this, 2, acceptVideoIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
            }

            // Decline call action
            Intent declineIntent = new Intent(this, Class.forName("com.tragofone.app.NotificationActionReceiver"));
            declineIntent.putExtra("notification_data", notificationData);
            declineIntent.putExtra("call_action", "decline");
            declineIntent.setAction("decline");
            declineIntent.setPackage(getPackageName());
            PendingIntent declinePendingIntent = PendingIntent.getBroadcast(
                this, 3, declineIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Delete intent for when notification is dismissed
            Intent deleteIntent = new Intent(this, Class.forName("com.tragofone.app.NotificationDismissReceiver"));
            deleteIntent.setAction("com.tragofone.app.NOTIFICATION_DISMISSED");
            deleteIntent.putExtra("notification_data", notificationData);
            PendingIntent deletePendingIntent = PendingIntent.getBroadcast(
                this, 4, deleteIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Get app icon
            ApplicationInfo appInfo = getApplicationInfo();
            int iconResId = appInfo.icon;
            
            // Build notification compatible with all Android versions
            // IMPORTANT: Set vibration pattern directly on notification for battery-restricted mode
            // This ensures vibration works even when foreground service is blocked
            long[] vibrationPattern = new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000};
            
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "call_channel_id")
                    .setSmallIcon(iconResId)
                    .setContentTitle(callerName != null ? callerName : callerNumber)
                    .setContentText(callerNumber)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .setVibrate(vibrationPattern); // Set vibration directly for battery-restricted mode
            
            // NO .setSound() - MediaPlayer handles audio for dynamic tone switching
            // Vibration is set directly on notification AND on channel for maximum compatibility
            Log.d("RingtoneService", "✅ Notification created (NO sound, WITH vibration pattern for battery-restricted mode)");
            
            // Continue building notification with actions
            builder
                    .addAction(new NotificationCompat.Action(
                            android.R.drawable.sym_action_call,
                            accept,
                            acceptPendingIntent
                    ))
                    .addAction(new NotificationCompat.Action(
                            android.R.drawable.ic_menu_close_clear_cancel,
                            decline,
                            declinePendingIntent
                    ))
                    .setDeleteIntent(deletePendingIntent);

            // Add video action if it's a video call
            if (isVideo && acceptVideoPendingIntent != null) {
                builder.addAction(new NotificationCompat.Action(
                        android.R.drawable.ic_menu_camera,
                        acceptVideo,
                        acceptVideoPendingIntent
                ));
            }

            return builder.build();

        } catch (Exception e) {
            Log.e("RingtoneService", "❌ Error creating incoming call notification: " + e.getMessage());
            e.printStackTrace();
            
            // Create a minimal notification as absolute fallback
            Log.d("RingtoneService", "🔄 Creating minimal notification as fallback");
            return new NotificationCompat.Builder(this, "call_channel_id")
                    .setContentTitle("Incoming Call")
                    .setContentText(callerNumber != null ? callerNumber : "Unknown")
                    .setSmallIcon(android.R.drawable.ic_menu_call)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .build();
        }
    }
    
    private String getLocalizedString(String langCode, String key) {
        try {
            // Map JavaScript language codes to Android locale codes
            String androidLocaleCode = mapLanguageToLocale(langCode);
            
            java.util.Locale locale = new java.util.Locale(androidLocaleCode);
            java.util.Locale.setDefault(locale);

            android.content.res.Configuration config = new android.content.res.Configuration(getResources().getConfiguration());
            config.setLocale(locale);

            Context localizedContext = createConfigurationContext(config);
            android.content.res.Resources resources = localizedContext.getResources();

            int resId = resources.getIdentifier(key, "string", getPackageName());
            if (resId == 0) {
                resId = getResources().getIdentifier(key, "string", getPackageName());
                return getString(resId);
            }

            return resources.getString(resId);
        } catch (Exception e) {
            Log.e("RingtoneService", "Error getting localized string: " + e.getMessage());
            return key; // fallback to key
        }
    }
    
    private String mapLanguageToLocale(String appLanguage) {
        switch (appLanguage) {
            case "ar": return "ar";
            case "de": return "de";
            case "en": return "en";
            case "es": return "es";
            case "fr": return "fr";
            case "gb": return "en-rGB";
            case "he": return "he";
            case "it": return "it";
            case "pt": return "pt-rBR";
            case "ru": return "ru";
            case "tr": return "tr";
            case "zh-cn": return "zh-rCN";
            case "zh-tw": return "zh-rTW";
            default: return "en";
        }
    }
    
    // Helper method to restart ziptone with gap
    private void restartZiptoneWithGap(Context context, Uri ringtoneUri) {
        if (!isStopped) {
            try {
                // Create a new MediaPlayer for each restart to avoid state issues
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                }
                
                // Create MediaPlayer and wait for it to be ready
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, ringtoneUri);
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_RING);
                
                // Make ringtoneUri final for inner class access
                final Uri finalRingtoneUri = ringtoneUri;
                
                // Set completion listener before preparing
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        if (!isStopped) {
                            // Wait for gap then restart
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (!isStopped) {
                                        restartZiptoneWithGap(context, finalRingtoneUri);
                                    }
                                }
                            }, 2000); // 2 second gap (matching your JS timing)
                        }
                    }
                });
                
                // Prepare and start
                mediaPlayer.prepare();
                mediaPlayer.start();
                Log.d("RingtoneService", "Restarted ziptone after gap with new MediaPlayer");
                
            } catch (Exception e) {
                Log.e("RingtoneService", "Error restarting ziptone: " + e.getMessage());
                // Fallback to default ringtone if ziptone fails
                Log.d("RingtoneService", "🔄 Ziptone restart failed, falling back to default ringtone");
                playDefaultRingtone(context, (AudioManager) getSystemService(Context.AUDIO_SERVICE));
            }
        }
    }

    /**
     * Log current ring volume without modifying it
     */
    private void ensureAppropriateRingVolume(AudioManager audioManager) {
        int streamType = AudioManager.STREAM_RING;
        int currentRingVolume = audioManager.getStreamVolume(streamType);
        int maxRingVolume = audioManager.getStreamMaxVolume(streamType);
        
        Log.d("RingtoneService", "Current ring volume: " + currentRingVolume + "/" + maxRingVolume + " (not modified)");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startManualVibrationLoop(final Vibrator vibrator, final long[] pattern) {
        // Stop any existing vibration first
        stopManualVibrationLoop();
        
        vibrationHandler = new Handler(Looper.getMainLooper());
        vibrationRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isStopped) {
                    try {
                        // Use 0 repeat (play once) and let handler control the loop
                        vibrator.vibrate(pattern, 0);
                    } finally {
                        // Calculate total pattern duration
                        long total = 0;
                        for (long l : pattern) total += l;
                        // Schedule next vibration after pattern completes
                        vibrationHandler.postDelayed(this, total);
                    }
                }
            }
        };
        vibrationHandler.post(vibrationRunnable);
    }

    private void stopManualVibrationLoop() {
        if (vibrationHandler != null && vibrationRunnable != null) {
            vibrationHandler.removeCallbacks(vibrationRunnable);
            vibrationHandler = null;
            vibrationRunnable = null;
        }

        if (vibrator != null) {
            vibrator.cancel(); // stops current vibration immediately
        }
    }


}