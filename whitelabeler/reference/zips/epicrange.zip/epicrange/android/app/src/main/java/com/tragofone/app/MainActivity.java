package com.tragofone.app;

import static android.app.UiModeManager.MODE_NIGHT_NO;
import static android.content.Intent.ACTION_CALL;
import static android.content.Intent.ACTION_CALL_BUTTON;
import static android.content.Intent.ACTION_DIAL;
import static android.content.Intent.ACTION_VIEW;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.app.ActivityManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.WindowManager;

import androidx.annotation.RequiresApi;

import com.facebook.react.HeadlessJsTaskService;
import com.facebook.react.ReactActivity;
import com.codegulp.invokeapp.RNInvokeApp;
import com.facebook.react.ReactActivityDelegate;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.modules.i18nmanager.I18nUtil;
import com.github.kevinejohn.keyevent.KeyEventModule;
import com.github.wumke.RNImmediatePhoneCall.RNImmediatePhoneCallPackage;  // <--- import
import com.facebook.react.defaults.DefaultReactActivityDelegate;

import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import android.app.PictureInPictureParams;
import android.util.Rational;
import android.os.Build;

import java.util.List;
import android.app.NotificationManager;
import org.json.JSONObject;
import org.json.JSONException; 
import android.os.Handler;
import android.os.Looper;

import javax.annotation.Nullable;

import io.wazo.callkeep.RNCallKeepModule;
import com.tragofone.app.CallEventModule;
import com.tragofone.app.RingtoneService;
import android.net.Uri;
import org.json.JSONObject;
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint;

public class MainActivity extends ReactActivity {

    /**
     * Returns the name of the main component registered from JavaScript. This is used to schedule
     * rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "TragofoneNew";
    }

    public  static Boolean isDarkMode = false;
    
    // Static variable to store call data for initial props
    private static String sCallAction = null;
    private static String sNotificationData = null;
    
    // Flag to track when call data is ready
    private static boolean sCallDataReady = false;
    
    // Reference to the delegate for immediate data transfer
    private static DelegateForNotification sDelegate = null;
    
    // Method to set call data from onNewIntent
    public static void setCallDataForProps(String callAction, String notificationData) {
        sCallAction = callAction;
        sNotificationData = notificationData;
        sCallDataReady = true;
        Log.d("MainActivity", "🔒 Call data stored for initial props: " + callAction);
        
        // If delegate is already created, update it immediately
        if (sDelegate != null) {
            Log.d("MainActivity", "🚀 Updating delegate immediately with call data");
            sDelegate.updatePropsWithCallData(callAction, notificationData);
        }
    }
    
    // Method to check if call data is ready
    public static boolean isCallDataReady() {
        return sCallDataReady;
    }
    
    // Method to get stored call data
    public static String[] getStoredCallData() {
        if (sCallDataReady) {
            String[] data = {sCallAction, sNotificationData};
            // Don't clear here, let DelegateForNotification handle it
            return data;
        }
        return null;
    }
    
    // Method to register delegate for immediate updates
    public static void registerDelegate(DelegateForNotification delegate) {
        sDelegate = delegate;
        Log.d("MainActivity", "🔗 Delegate registered for immediate updates");
        
        // If we already have call data, update immediately
        if (sCallDataReady && sCallAction != null && sNotificationData != null) {
            Log.d("MainActivity", "🚀 Delegate registered, updating immediately with existing call data");
            delegate.updatePropsWithCallData(sCallAction, sNotificationData);
        }
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //TRAG-5146 App crash issue fixed in background state.( official docs link for fix ) https://github.com/software-mansion/react-native-screens#android
        super.onCreate(null);
        I18nUtil sharedI18nUtilInstance = I18nUtil.getInstance();
        sharedI18nUtilInstance.allowRTL(getApplicationContext(), true);
        RNInvokeApp.sendEvent();
        
        Log.e("MainActivity", "onCreate: ");
        
        handleNotificationIntent(getIntent());
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        getReactInstanceManager().onConfigurationChanged(this, newConfig);
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            Log.d("[Main Activity]", "Found new intent");
            Log.d("[Main Activity]", "Intent action: " + intent.getAction());
            Log.d("[Main Activity]", "Intent extras: " + intent.getExtras());
            
            // Check if we have call data and store it for initial props
            if (intent.hasExtra("call_action") && intent.hasExtra("notification_data")) {
                String callAction = intent.getStringExtra("call_action");
                String notificationData = intent.getStringExtra("notification_data");
                Log.d("MainActivity", "🎯 onNewIntent: Storing call data for initial props: " + callAction);
                setCallDataForProps(callAction, notificationData);
            }
            
            String number = handleIntentParams(intent);
            if (!number.isEmpty()) {
                KeyEventModule module = KeyEventModule.getInstance();
                if (module != null) {
                    module.onCallIntentEvent(number);
                } else {
                    Log.d("MainActivity", "KeyEventModule not ready; skipping onCallIntentEvent");
                }
            }
        }
        setIntent(intent); // Required to ensure getIntent() returns the updated one
        handleNotificationIntent(intent);
    }

    private void handleNotificationIntent(Intent intent) {

    Log.e("MainActivity", "handleNotificationIntent: ");
    Log.e("MainActivity", "intent: " + intent);
    Log.e("MainActivity", "intent.hasExtra(\"call_action\"): " + intent.hasExtra("call_action"));
    Log.e("MainActivity", "intent.hasExtra(\"notification_data\"): " + intent.hasExtra("notification_data"));
    
    if (intent != null && intent.hasExtra("call_action")) {
        String action = intent.getStringExtra("call_action");
        String notificationData = intent.getStringExtra("notification_data");

        Log.d("MainActivity", "Intent received in handleNotificationIntent: action=" + action + ", data=" + notificationData);
        Log.d("MainActivity", "App state: " + getLifecycle().getCurrentState());

        // DIRECT SYNCHRONOUS EXECUTION - No queues, immediate execution
        WritableMap map = Arguments.createMap();
        map.putString("call_action", action);
        map.putString("notification_data", notificationData);
        
        Log.d("MainActivity", "About to emit CallAction event to JS");
        CallEventModule.emitEventToJS("CallAction", map);
        Log.d("MainActivity", "CallAction event emitted to JS");
        
        // Stop RingtoneService immediately
        stopService(new Intent(this, RingtoneService.class));


        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                Log.d("MainActivity", "Delayed cancel of notification 1001");
                notificationManager.cancel(1001);
            }

            // // ✅ Parse the notificationData to get caller_number
            // NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
            // if (notificationManager != null) {
            //     notificationManager.cancel("1001", 1001); // fallback
            //     String fromNumber = null;
            //     try {
            //         // Parse the notification data to get fromnumber
            //         org.json.JSONObject jsonData = new org.json.JSONObject(notificationData);
            //         fromNumber = jsonData.optString("fromnumber", null);
            //     } catch (org.json.JSONException e) {
            //         Log.e("MainActivity", "Error parsing notification data JSON: " + e.getMessage());
            //     }
                
            //     if (fromNumber != null && !fromNumber.isEmpty()) {
            //         Log.d("MainActivity", "Cancelling notification with tag: " + fromNumber + " and ID: 1001");
            //         notificationManager.cancel(fromNumber, 1001);
            //     } else {
            //         Log.d("MainActivity", "Fallback cancel with tag: \"1001\" and ID: 1001");
            //         notificationManager.cancel("1001", 1001); // fallback
            //     }
            // }
        }, 10); // Reduced to 10ms for faster execution

    }
    }

    // Cold start handling - simple and direct
    private void handleColdStartIntent(Intent intent) {
        if (intent != null && intent.hasExtra("call_action")) {
            String action = intent.getStringExtra("call_action");
            String notificationData = intent.getStringExtra("notification_data");
            
            Log.d("MainActivity", "🔄 Cold start: Processing intent - action: " + action);
            
            // Emit event immediately
            WritableMap map = Arguments.createMap();
            map.putString("call_action", action);
            map.putString("notification_data", notificationData);
            CallEventModule.emitEventToJS("CallAction", map);
            
            Log.d("MainActivity", "✅ Cold start: Event emitted successfully");
        }
    }
    
    /**
     * Process call actions (Accept/Decline) from notifications
     * This method can be called from BroadcastReceiver or directly
     */
    public void processCallAction(String action, String notificationData) {
        Log.d("MainActivity", "🎯 Processing call action: " + action + ", data: " + notificationData);
        
        try {
            // Create the event data
            WritableMap map = Arguments.createMap();
            map.putString("call_action", action);
            map.putString("notification_data", notificationData);
            
            // Emit the event to JavaScript
            CallEventModule.emitEventToJS("CallAction", map);
            
            Log.d("MainActivity", "✅ Call action event emitted successfully: " + action);
            
            // Stop the ringtone service
            stopService(new Intent(this, RingtoneService.class));
            
            // Cancel the notification
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (notificationManager != null) {
                    Log.d("MainActivity", "🔔 Cancelling notification after action: " + action);
                    notificationManager.cancel(1001);
                }
            }, 100);
            
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error processing call action: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Process call action from intent and emit event to JavaScript
     */
    private static void processCallActionFromIntent(String action, String notificationData) {
        Log.d("MainActivity", "🎯 Processing call action from intent: " + action);
        
        try {
            // Create the event data
            WritableMap map = Arguments.createMap();
            map.putString("call_action", action);
            map.putString("notification_data", notificationData);
            
            // Emit the event to JavaScript
            CallEventModule.emitEventToJS("CallAction", map);
            
            Log.d("MainActivity", "✅ Call action event emitted from intent: " + action);
            
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error processing call action from intent: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String handleIntentParams(Intent intent) {
        String number = "";
        Boolean isTragofoneCommands = false;
        if (intent != null) {
            Log.i("Main Activity", "Handling intent with action: " + intent.getAction()
                    + ", type " + intent.getType() + " and data " + intent.getData());

            Log.e("onNewIntent: getExtras: ", String.valueOf(intent.getExtras()));
            
            // ALWAYS check for call action data first, regardless of intent action
            String notificationAction = getCallActionFromIntent(intent);
            String notificationData = getNotificationDataFromIntent(intent);
            
            if (notificationAction != null && notificationData != null) {
                Log.d("MainActivity", "🎯 Call action data found in intent: " + notificationAction);
                Log.d("MainActivity", "🎯 Notification data: " + notificationData);
                
                // Process the call action immediately
                processCallActionFromIntent(notificationAction, notificationData);
            } else {
                Log.d("MainActivity", "❌ No call action data found in handleIntentParams");
            }
            
            // Then handle other intent types
            if (intent.getAction() != null) {
                switch (intent.getAction()) {
                    case ACTION_DIAL:
                    case ACTION_VIEW:
                    case ACTION_CALL_BUTTON:
                    case ACTION_CALL: {
                        String uri = intent.getDataString();
                        Log.e("onNewIntent: data: string uri: ", uri);
                        if (uri.contains("tragofonecommands:")) {
                            isTragofoneCommands = true;
                            break;
                        }
                        if (uri != null && !uri.isEmpty()) {
                            number = handleTelOrSipUri(uri);
                        }
                        break;
                    }
                    case "accept_audio":
                    case "accept_video":
                    case "decline": {
                        // This is already handled above, but log for debugging
                        Log.d("MainActivity", "Custom notification action: " + notificationAction);
                        Log.d("MainActivity", "Custom notification data: " + notificationData);
                        break;
                    }
                    default:
                        break;
                }
            }
            
            if (Intent.ACTION_SEND.equals(intent.getAction()) || Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction())) {

            } else {
                if (!isTragofoneCommands) {
                    // Prevent this intent to be processed again
                    intent.setAction(null);
                    intent.setData(null);    
                }
            }

        }
        return number;
    }

    private static String handleTelOrSipUri(String uri) {
        String number = "";
        if (uri.contains("tel:")) {
            number = uri.split(":")[1];
            Log.e("onNewIntent: handleTelOrSipUri: ", number);
        } else {
            number = uri;
        }
        return number;
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.d("PipModule", "🚀 User is leaving the app. Entering PiP...");
        sendEventToReactNative("APP_GOING_BACKGROUND");
    }


    private void sendEventToReactNative(String eventName) {
        ReactInstanceManager reactInstanceManager = getReactNativeHost().getReactInstanceManager();
        ReactContext reactContext = reactInstanceManager.getCurrentReactContext();

        if (reactContext instanceof ReactApplicationContext) {
            ((ReactApplicationContext) reactContext)
                    .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                    .emit(eventName, null);
        } else {
            Log.e("PipModule", "❌ ReactContext is null. Cannot send event!");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            this.setShowWhenLocked(false);
            this.setTurnScreenOn(false);
        }
        //custom code
        try {
            if (!isAppOnForeground(this)) {
                Intent service = new Intent(this, onAppStopService.class);
                service.putExtra("something", "something1");
                Bundle bundle = new Bundle();
                bundle.putString("foo", "bar");
                service.putExtras(bundle);
                this.startService(service);
                HeadlessJsTaskService.acquireWakeLockNow(this);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        RNImmediatePhoneCallPackage.onRequestPermissionsResult(requestCode, permissions, grantResults); // very important event callback
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            if (requestCode == RNCallKeepModule.REQUEST_READ_PHONE_STATE) {
                RNCallKeepModule.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }

    private boolean isAppOnForeground(Context context) {
        /**
         We need to check if app is in foreground otherwise the app will crash.
         http://stackoverflow.com/questions/8489993/check-android-application-is-in-foreground-or-not
         **/
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses =
                activityManager.getRunningAppProcesses();
        if (appProcesses == null) {
            return false;
        }
        final String packageName = context.getPackageName();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.importance ==
                    ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND &&
                    appProcess.processName.equals(packageName)) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onResume() {
        try {
            boolean isIncomingCall = false;
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                String data = extras.getString("notification_data");
                Log.e("MainActivity", "onResume: " + data );
                if (data != null && data.contains("pcs_ip")) {
                    isIncomingCall = true;
                }
            }
            Log.e("MainActivity", "onResume: isIncomingCall: "+ isIncomingCall );
            if (isIncomingCall) {
                getIntent().removeExtra("notification_data");
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    this.setShowWhenLocked(true);
                    this.setTurnScreenOn(true);
                }
            } else {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    this.setShowWhenLocked(true);
                    this.setTurnScreenOn(true);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onResume();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (action == KeyEvent.ACTION_UP || action == KeyEvent.ACTION_DOWN) {
                    KeyEventModule.getInstance().onKeyDownEvent(keyCode, event);
                }
                break;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (action == KeyEvent.ACTION_DOWN || action == KeyEvent.ACTION_UP) {
                    KeyEventModule.getInstance().onKeyDownEvent(keyCode, event);
                }
                break;
        }
        return super.dispatchKeyEvent(event);
    }


    public void onUIModeChanged(Boolean isDarkMode) {
        MainActivity.isDarkMode = isDarkMode;
        Log.e(getClass().getSimpleName(), "onUIModeChanged: Received In MainActivity");

        Intent intent = new Intent(getPackageName() + "MY_BROADCAST");
        intent.putExtra("data", isDarkMode);
        sendBroadcast(intent);
        UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (isDarkMode)
                uiModeManager.setApplicationNightMode(UiModeManager.MODE_NIGHT_YES);
            else
                uiModeManager.setApplicationNightMode(MODE_NIGHT_NO);
        }

    }

    public static class DelegateForNotification extends ReactActivityDelegate {
        private static final String NOTIFICATION_DATA = "notification_data";
        private Bundle mInitialProps = null;
        private final
        Activity mActivity;

        public DelegateForNotification(Activity activity, String mainComponentName) {
            super(activity, mainComponentName);
            this.mActivity = activity;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            Bundle bundle = mActivity.getIntent().getExtras();
            String number = handleIntentParams(mActivity.getIntent());
            mInitialProps = new Bundle();
            
            Log.d("DelegateForNotification", "🔍 onCreate: Checking for call data...");
            Log.d("DelegateForNotification", "🔍 Call data ready: " + MainActivity.isCallDataReady());
            Log.d("DelegateForNotification", "🔍 Stored call action: " + sCallAction);
            Log.d("DelegateForNotification", "🔍 Stored notification data: " + sNotificationData);
            Log.d("DelegateForNotification", "🔍 Intent extras: " + bundle);
            
            // Register this delegate for immediate updates
            MainActivity.registerDelegate(this);
            
            // Use stored call data if available
            if (sCallAction != null && sNotificationData != null) {
                Log.d("DelegateForNotification", "🎯 Using stored call data for initial props: " + sCallAction);
                mInitialProps.putString("call_action", sCallAction);
                mInitialProps.putString(NOTIFICATION_DATA, sNotificationData);
                
                // Clear the stored data after using it
                sCallAction = null;
                sNotificationData = null;
                sCallDataReady = false;
            } else {
                // Fallback to intent extras (for normal app launch)
                Log.d("DelegateForNotification", "🔄 Using intent extras as fallback");
                if (bundle != null && bundle.containsKey(NOTIFICATION_DATA)) {
                    mInitialProps.putString(NOTIFICATION_DATA, bundle.getString(NOTIFICATION_DATA));
                }
                if (bundle != null && bundle.containsKey("call_action")) {
                    mInitialProps.putString("call_action", bundle.getString("call_action"));
                }
            }
            
            Log.d("DelegateForNotification", "📦 Final initial props: " + mInitialProps);
            
            if (!number.isEmpty()) {
                Log.e("DelegateForNotification onCreate", "getLaunchOptions: number_to_call: " + number);
                mInitialProps.putString("number_to_call", number);
            }
            super.onCreate(savedInstanceState);
        }
        
        private void scheduleCallDataCheck() {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (MainActivity.isCallDataReady()) {
                    Log.d("DelegateForNotification", "🔄 Call data now available, updating props");
                    // The data is now available, but we can't modify initial props after onCreate
                    // We'll emit an event to JavaScript instead
                    emitCallDataEvent();
                }
            }, 200); // Wait 200ms for onNewIntent to complete
        }
        
        private void emitCallDataEvent() {
            try {
                String[] callData = MainActivity.getStoredCallData();
                if (callData != null) {
                    Log.d("DelegateForNotification", "📤 Emitting call data event to JS");
                    // Emit event to JavaScript since we can't modify initial props
                    WritableMap map = Arguments.createMap();
                    map.putString("call_action", callData[0]);
                    map.putString("notification_data", callData[1]);
                    CallEventModule.emitEventToJS("CallAction", map);
                    
                    // Clear the stored data
                    sCallAction = null;
                    sNotificationData = null;
                    sCallDataReady = false;
                }
            } catch (Exception e) {
                Log.e("DelegateForNotification", "❌ Error emitting call data event", e);
            }
        }

        // New method to update props immediately
        public void updatePropsWithCallData(String callAction, String notificationData) {
            Log.d("DelegateForNotification", "🚀 Updating delegate with call data from MainActivity");
            mInitialProps.putString("call_action", callAction);
            mInitialProps.putString(NOTIFICATION_DATA, notificationData);
            Log.d("DelegateForNotification", "📦 Updated initial props: " + mInitialProps);
        }
        
        @Override
        public void onPause() {
            super.onPause();
        }

        @Override
        protected Bundle getLaunchOptions() {
            return mInitialProps;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
    }

    /**
     * Returns the instance of the {@link ReactActivityDelegate}. Here we use a util class {@link
     * DefaultReactActivityDelegate} which allows you to easily enable Fabric and Concurrent React
     * (aka React 18) with two boolean flags.
     */
    @Override
    protected ReactActivityDelegate createReactActivityDelegate() {
        return new DelegateForNotification(this, getMainComponentName());
    }

    /**
     * Extract call action from intent using multiple methods
     */
    private static String getCallActionFromIntent(Intent intent) {
        if (intent == null) return null;
        
        // Method 1: Try extras first
        String callAction = intent.getStringExtra("call_action");
        if (callAction != null) {
            Log.d("MainActivity", "✅ Call action found in extras: " + callAction);
            return callAction;
        }
        
        // Method 2: Try data URI
        Uri data = intent.getData();
        if (data != null) {
            String dataString = data.toString();
            Log.d("MainActivity", "🔍 Checking data URI: " + dataString);
            
            if (dataString.contains("call_action=")) {
                String[] parts = dataString.split("call_action=");
                if (parts.length > 1) {
                    String[] actionParts = parts[1].split("&");
                    callAction = actionParts[0];
                    Log.d("MainActivity", "✅ Call action found in data URI: " + callAction);
                    return callAction;
                }
            }
        }
        
        // Method 3: Try action field
        String action = intent.getAction();
        if (action != null && (action.equals("accept_audio") || action.equals("accept_video") || action.equals("decline"))) {
            Log.d("MainActivity", "✅ Call action found in intent action: " + action);
            return action;
        }
        
        Log.d("MainActivity", "❌ No call action found in intent");
        return null;
    }
    
    /**
     * Extract notification data from intent using multiple methods
     */
    private static String getNotificationDataFromIntent(Intent intent) {
        if (intent == null) return null;
        
        // Method 1: Try extras first
        String notificationData = intent.getStringExtra("notification_data");
        if (notificationData != null) {
            Log.d("MainActivity", "✅ Notification data found in extras: " + notificationData);
            return notificationData;
        }
        
        // Method 2: Try data URI
        Uri data = intent.getData();
        if (data != null) {
            String dataString = data.toString();
            Log.d("MainActivity", "🔍 Checking data URI for notification data: " + dataString);
            
            if (dataString.contains("notification_data=")) {
                String[] parts = dataString.split("notification_data=");
                if (parts.length > 1) {
                    String[] dataParts = parts[1].split("&");
                    notificationData = dataParts[0];
                    Log.d("MainActivity", "✅ Notification data found in data URI: " + notificationData);
                    return notificationData;
                }
            }
        }
        
        // Method 3: Try to construct from available data
        String callerNumber = intent.getStringExtra("caller_number");
        String callerName = intent.getStringExtra("caller_name");
        if (callerNumber != null || callerName != null) {
            try {
                JSONObject jsonData = new JSONObject();
                if (callerNumber != null) jsonData.put("fromnumber", callerNumber);
                if (callerName != null) jsonData.put("caller_name", callerName);
                jsonData.put("is_video", "false");
                jsonData.put("uuid", "cold_start_" + System.currentTimeMillis());
                
                notificationData = jsonData.toString();
                Log.d("MainActivity", "✅ Notification data constructed from available data: " + notificationData);
                return notificationData;
            } catch (Exception e) {
                Log.e("MainActivity", "❌ Error constructing notification data", e);
            }
        }
        
        Log.d("MainActivity", "❌ No notification data found in intent");
        return null;
    }
}
