package com.tragofone.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;


public class NotificationActionReceiver extends BroadcastReceiver {
    private static final String TAG = "NotificationActionReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        final PendingResult pendingResult = goAsync(); // important!

        new Thread(() -> {
            try {
                String action = intent.getAction();
                String data = intent.getStringExtra("notification_data");
                context.stopService(new Intent(context, RingtoneService.class));

                NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (notificationManager != null) {
                    notificationManager.cancel(1001);
                }

                if ("decline".equals(action)) {
                    JSONObject json = new JSONObject(data);
                    String declineUuid = json.optString("decline_uuid", "");
                    Log.d("NotificationAction", "🔴 Decline UUID: " + declineUuid);

                    WebServiceHelper.declineCall(context, declineUuid, new WebServiceHelper.WebServiceCallback() {
                        @Override
                        public void onSuccess(String response) {
                            Log.d("NotificationAction", "✅ Decline call successful: " + response);
                            pendingResult.finish(); // Finish after success
                        }

                        @Override
                        public void onError(String error) {
                            Log.e("NotificationAction", "❌ Decline call failed: " + error);
                            pendingResult.finish(); // Finish after error
                        }
                    });
                } else {
                    pendingResult.finish(); // No action
                }
            } catch (Exception e) {
                Log.e("NotificationAction", "⚠️ Exception", e);
                pendingResult.finish(); // Always finish
            }
        }).start();
    }
}
