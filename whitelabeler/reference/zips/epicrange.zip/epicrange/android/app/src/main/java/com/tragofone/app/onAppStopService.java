package com.tragofone.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.facebook.react.HeadlessJsTaskService;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.jstasks.HeadlessJsTaskConfig;
// import com.google.firebase.messaging.RemoteMessage;

import javax.annotation.Nullable;

import io.invertase.firebase.common.ReactNativeFirebaseJSON;
import io.invertase.firebase.messaging.ReactNativeFirebaseMessagingSerializer;



public class onAppStopService extends HeadlessJsTaskService {
    private static final long TIMEOUT_DEFAULT = 60000;
    private static final String TIMEOUT_JSON_KEY = "messaging_android_headless_task_timeout";
    private static final String TASK_KEY = "onAppStopHeadlessTask";

    @Override
    protected @Nullable
    HeadlessJsTaskConfig getTaskConfig(Intent intent) {
        // Toast.makeText(this,"running from android side",Toast.LENGTH_LONG).show();
//        Bundle extras = intent.getExtras();
//        if (extras != null) {
//            return new HeadlessJsTaskConfig(
//                    TASK_KEY,
//                    Arguments.fromBundle(extras),
//                    10000, // timeout for the task
//                    false
//            );
//        }
//        return null;

        Bundle extras = intent.getExtras();
        if (extras == null) return null;

        return new HeadlessJsTaskConfig(
                TASK_KEY,
                Arguments.fromBundle(extras),
                ReactNativeFirebaseJSON.getSharedInstance().getLongValue(TIMEOUT_JSON_KEY, TIMEOUT_DEFAULT),
                // Prevents race condition where the user opens the app at the same time as a notification
                // is delivered, causing a crash.
                true
        );
    }
}
