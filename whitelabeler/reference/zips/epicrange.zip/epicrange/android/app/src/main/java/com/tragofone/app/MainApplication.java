package com.tragofone.app;

import android.app.Application;
import android.util.Log;

import com.facebook.react.PackageList;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint;
import com.facebook.react.defaults.DefaultReactNativeHost;
import com.facebook.react.soloader.OpenSourceMergedSoMapping;
import java.io.IOException;
import com.facebook.soloader.SoLoader;
import com.tragofone.app.BuildConfig;
import com.vinzscam.reactnativefileviewer.RNFileViewerPackage;
import java.util.List;
//import io.wazo.callkeep.RNCallKeepPackage;
import com.meedan.ShareMenuPackage;
public class MainApplication extends Application implements ReactApplication {

  private final ReactNativeHost mReactNativeHost =
      new DefaultReactNativeHost(this) {
        @Override
        public boolean getUseDeveloperSupport() {
          return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
          @SuppressWarnings("UnnecessaryLocalVariable")
          List<ReactPackage> packages = new PackageList(this).getPackages();
          // Packages that cannot be autolinked yet can be added manually here, for example:
          // packages.add(new MyReactNativePackage());
//            packages.add(new RNCallKeepPackage());
            new RNFileViewerPackage();
            new ShareMenuPackage();
            packages.add(new CallStateChangeManager());
            packages.add(new MyCustomPackage());
            packages.add(new PipPackage());
            packages.add(new CRMModulePackage());
            packages.add(new CallEventPackage());
            packages.add(new FullScreenIntentPackage());
          return packages;
        }

        @Override
        protected String getJSMainModuleName() {
          return "index";
        }

        @Override
        protected boolean isNewArchEnabled() {
          return BuildConfig.IS_NEW_ARCHITECTURE_ENABLED;
        }

        @Override
        protected Boolean isHermesEnabled() {
          return BuildConfig.IS_HERMES_ENABLED;
        }
      };

  @Override
  public ReactNativeHost getReactNativeHost() {
    return mReactNativeHost;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    try {
          SoLoader.init(this, OpenSourceMergedSoMapping.INSTANCE);
          Log.e("MainApplication.java", "Success to initialize SoLoader with OpenSourceMergedSoMapping");
      } catch (IOException e) {
          Log.e("MainApplication.java", "Failed to initialize SoLoader with OpenSourceMergedSoMapping", e);
      }
    if (BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) {
      // If you opted-in for the New Architecture, we load the native entry point for this app.
      DefaultNewArchitectureEntryPoint.load();
    }
  }
}
