package com.tragofone.app;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Helper class to write native Android logs to the same file as react-native-file-logger
 * This ensures that native Android logs are written to the same file as React Native logs
 * 
 * This class writes directly to the same log file location that react-native-file-logger uses
 * without relying on SLF4J to avoid dependency conflicts.
 */
public class FileLoggerHelper {
    private static final String TAG = "FileLoggerHelper";
    private static String logFilePath = null;
    private static boolean isConfigured = false;
    private static final SimpleDateFormat dateFormat;
    
    static {
        dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    }
    
    /**
     * Configure the file logger to write to the same location as react-native-file-logger
     * This should be called once during app initialization
     */
    public static void configure(Context context) {
        if (isConfigured) {
            return;
        }
        
        try {
            // Use the same directory as react-native-file-logger
            String logsDirectory = context.getExternalCacheDir() + "/logs";
            String logPrefix = context.getPackageName();
            
            // Create logs directory if it doesn't exist
            File logDir = new File(logsDirectory);
            if (!logDir.exists()) {
                logDir.mkdirs();
            }
            
            // Use the same file naming convention as react-native-file-logger
            logFilePath = logsDirectory + "/" + logPrefix + "-latest.log";
            isConfigured = true;
            
            Log.d(TAG, "File logger configured successfully. Logs will be written to: " + logFilePath);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure file logger: " + e.getMessage(), e);
        }
    }
    
    /**
     * Write a log message to the file
     */
    private static void writeToFile(String level, String tag, String message) {
        if (!isConfigured || logFilePath == null) {
            return;
        }
        
        try {
            String timestamp = dateFormat.format(new Date());
            String logEntry = String.format("%s [%s] %-5s %s - [%s] %s%n", 
                timestamp, "main", level, "NativeAndroid", tag, message);
            
            // Append to the log file
            FileWriter writer = new FileWriter(logFilePath, true);
            writer.write(logEntry);
            writer.close();
            
        } catch (IOException e) {
            Log.e(TAG, "Failed to write to log file: " + e.getMessage());
        }
    }
    
    /**
     * Log a debug message to both Android Log and file
     */
    public static void debug(String tag, String message) {
        Log.d(tag, message);
        writeToFile("DEBUG", tag, message);
    }
    
    /**
     * Log an info message to both Android Log and file
     */
    public static void info(String tag, String message) {
        Log.i(tag, message);
        writeToFile("INFO", tag, message);
    }
    
    /**
     * Log a warning message to both Android Log and file
     */
    public static void warn(String tag, String message) {
        Log.w(tag, message);
        writeToFile("WARN", tag, message);
    }
    
    /**
     * Log an error message to both Android Log and file
     */
    public static void error(String tag, String message) {
        Log.e(tag, message);
        writeToFile("ERROR", tag, message);
    }
    
    /**
     * Log an error message with exception to both Android Log and file
     */
    public static void error(String tag, String message, Throwable throwable) {
        Log.e(tag, message, throwable);
        String fullMessage = message + " - " + Log.getStackTraceString(throwable);
        writeToFile("ERROR", tag, fullMessage);
    }
    
    /**
     * Check if the file logger is configured and ready to use
     */
    public static boolean isConfigured() {
        return isConfigured && logFilePath != null;
    }
}
