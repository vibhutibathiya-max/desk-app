package com.tragofone.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import java.util.HashMap;
import java.util.Map;

public class CallStateChangeModule extends ReactContextBaseJavaModule implements Application.ActivityLifecycleCallbacks, CustomTelephonyCallback.PhoneCallStateCallback {

    private ReactApplicationContext reactContext;
    private TelephonyManager tm;
    private final int REQUEST_CODE = 27867;
    private CallStateChangeActionModule jsModule = null;
    private CustomTelephonyCallback customTelephonyCallback;
    private Activity activity = null;
    private boolean wasAppInOffHook = false;
    private boolean wasAppInRinging = false;
    CallStateChangeModule(ReactApplicationContext context) {
        super(context);
        reactContext = context;
    }

    @NonNull
    @Override
    public String getName() {
        return CallStateChangeManager.class.getSimpleName();
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    @ReactMethod
    public void registerTelephonyCallback(){
        Log.d("TelephonyModule", "ReactNativeJS PhonseState registerTelephonyCallback: ");
        if (activity == null) {
            activity = getCurrentActivity();
            if (activity != null) {
                activity.getApplication().registerActivityLifecycleCallbacks(this);
            }
        }
        TelephonyManager telephonyManager = (TelephonyManager) reactContext.getSystemService(Context.TELEPHONY_SERVICE);
//        SubscriptionManager sm = SubscriptionManager.from(reactContext);
        int subId = SubscriptionManager.getDefaultSubscriptionId();
        tm = telephonyManager.createForSubscriptionId(subId);
        customTelephonyCallback = new CustomTelephonyCallback(this);
        Binder.clearCallingIdentity();
        tm.registerTelephonyCallback(reactContext.getMainExecutor(), customTelephonyCallback);
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    @ReactMethod
    public void unregisterTelephonyCallback(){
        Log.d("TelephonyModule", "ReactNativeJS PhonseState unregisterTelephonyCallback: ");
        tm.unregisterTelephonyCallback(customTelephonyCallback);
        customTelephonyCallback = null;
        tm = null;
    }

    /**
     * @return a map of constants this module exports to JS. Supports JSON types.
     */
    public Map<String, Object> getConstants() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("Incoming", "Incoming");
        map.put("Offhook", "Offhook");
        map.put("Disconnected", "Disconnected");
        map.put("Missed", "Missed");
        return map;
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
    }

    @Override
    public void onPhoneCallStateChange(int state) {
        Log.d("TelephonyModule", "onPhoneCallStateChange: " + state);
        jsModule = this.reactContext.getJSModule(CallStateChangeActionModule.class);
        switch (state){
            //Hangup
            case TelephonyManager.CALL_STATE_IDLE:
                if(wasAppInOffHook == true) { // if there was an ongoing call and the call state switches to idle, the call must have gotten disconnected
                    jsModule.callStateChanged("Disconnected");
                } else if(wasAppInRinging == true) { // if the phone was ringing but there was no actual ongoing call, it must have gotten missed
                    jsModule.callStateChanged("Missed");
                }

                //reset device state
                wasAppInRinging = false;
                wasAppInOffHook = false;
                Log.e("TelephonyModule", "IDLE");
                break;
            //Outgoing
            case TelephonyManager.CALL_STATE_OFFHOOK:
                //Device call state: Off-hook. At least one call exists that is dialing, active, or on hold, and no calls are ringing or waiting.
                wasAppInOffHook = true;
                jsModule.callStateChanged("Offhook");
                Log.e("TelephonyModule", "OFFHOOK");
                break;
            //Incoming
            case TelephonyManager.CALL_STATE_RINGING:
                // Device call state: Ringing. A new call arrived and is ringing or waiting. In the latter case, another call is already active.
                wasAppInRinging = true;
                jsModule.callStateChanged("Incoming");
                Log.e("TelephonyModule", "RINGING");
                break;
        }
    }

    @ReactMethod
    public void onModeChangedFromReact(Boolean isDarkMode) {
        Log.e("CallStateChanged", "onModeChanged: Triggered"+isDarkMode);
//        if(activity == null){
//            activity = getCurrentActivity();
//            if (activity != null) {
//                activity.getApplication().registerActivityLifecycleCallbacks(this);
//            }
//        }
//
//        if (activity instanceof MainActivity) {
//            ((MainActivity) activity).onUIModeChanged(isDarkMode);
//        }else{
//            Log.e("CallStateChanged", "onModeChanged: Else part");
//        }
    }
}
