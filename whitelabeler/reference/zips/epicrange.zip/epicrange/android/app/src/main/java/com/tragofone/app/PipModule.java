package com.tragofone.app;

import android.app.PictureInPictureParams;
import android.content.res.Configuration;
import android.util.Rational;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import android.util.DisplayMetrics;
import android.os.Build;
import android.app.Activity;
import android.content.Intent;

public class PipModule extends ReactContextBaseJavaModule {

  private static boolean shouldEnablePiP = false;

  public PipModule(ReactApplicationContext reactContext) {
    super(reactContext);
  }

  @Override
  public String getName() {
    return "PipModule";
  }

  @ReactMethod
  public void enterPipMode() {
      Activity activity = getCurrentActivity();
      if (activity == null) {
          return;
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && shouldEnablePiP) {
          Rational aspectRatio = new Rational(9, 16);
          PictureInPictureParams.Builder pipBuilder = new PictureInPictureParams.Builder();
          pipBuilder.setAspectRatio(aspectRatio);
          // Prevent background transition
          activity.enterPictureInPictureMode(pipBuilder.build());
      }
  }

  @ReactMethod
  public void exitPipMode() {
      Activity activity = getCurrentActivity();
      if (activity != null) {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
              // Exit PiP by reloading the main activity
              Intent intent = new Intent(activity, MainActivity.class);
              intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
              activity.startActivity(intent);
          }
      }
  }

@ReactMethod
    public void setShouldEnablePiP(boolean enablePiP) {
        shouldEnablePiP = enablePiP;
    }

@ReactMethod
public void setAspectRatio(float heightFactor) {
  if (getCurrentActivity() != null && getCurrentActivity().isInPictureInPictureMode()) {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    getCurrentActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
    int screenWidth = displayMetrics.widthPixels;
    int screenHeight = displayMetrics.heightPixels;

    float aspectRatio = 9f / 16f;

    int pipWidth;
    int pipHeight;
    if (screenWidth > screenHeight) {
      pipWidth = screenHeight;
      pipHeight = (int) (screenHeight / aspectRatio);
    } else {
      pipWidth = screenWidth;
      pipHeight = (int) (screenWidth / aspectRatio);
    }

    // Increase the height by the specified factor
    pipHeight = (int) (pipHeight * heightFactor);

    PictureInPictureParams.Builder pipBuilder = new PictureInPictureParams.Builder();

    // Check if the setAspectRatio method is available (added in API level 31)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      Rational aspectRatioRational = new Rational(pipWidth, pipHeight);
      pipBuilder.setAspectRatio(aspectRatioRational);
    } else {
      // Handle earlier Android versions
    }

    PictureInPictureParams params = pipBuilder.build();

    getCurrentActivity().setPictureInPictureParams(params);
  }
}



  @ReactMethod
  public boolean isInPipMode() {
    return getCurrentActivity() != null && getCurrentActivity().isInPictureInPictureMode();
  }

  public void onConfigurationChanged(Configuration newConfig) {
    // Handle configuration changes if necessary
  }
}
