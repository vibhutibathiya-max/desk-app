package com.tragofone.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

public class ContactHelper extends ReactContextBaseJavaModule {
    public ContactHelper(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return "ContactHelper";
    }

    @ReactMethod
    public void saveCallerName(String callerName) {
        SharedPreferences prefs = getReactApplicationContext().getSharedPreferences("IncomingCaller", Context.MODE_PRIVATE);
        prefs.edit().putString("caller_name", callerName).apply();
    }

    @ReactMethod
    public String getCallerName() {
        SharedPreferences prefs = getReactApplicationContext().getSharedPreferences("IncomingCaller", Context.MODE_PRIVATE);
        return prefs.getString("caller_name", "");
    }
}
