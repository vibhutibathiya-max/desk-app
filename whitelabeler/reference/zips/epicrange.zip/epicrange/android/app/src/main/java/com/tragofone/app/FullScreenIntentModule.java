package com.tragofone.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;

public class FullScreenIntentModule extends ReactContextBaseJavaModule {
    private static final String TAG = "FullScreenIntentModule";
    private final ReactApplicationContext reactContext;

    public FullScreenIntentModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @NonNull
    @Override
    public String getName() {
        return "FullScreenIntentModule";
    }

    @ReactMethod
    public void canUseFullScreenIntent(Promise promise) {
        try {
            boolean canUse = false;
            boolean hasPermissionScreen = false;
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14 (API 34) and above - use the new NotificationManager API
                try {
                    android.app.NotificationManager notificationManager = 
                        (android.app.NotificationManager) reactContext.getSystemService(android.content.Context.NOTIFICATION_SERVICE);
                    canUse = notificationManager.canUseFullScreenIntent();
                    hasPermissionScreen = true; // Android 14+ has the permission screen
                } catch (Exception e) {
                    Log.e(TAG, "Error using NotificationManager.canUseFullScreenIntent()", e);
                    // Fallback to older method
                    canUse = Settings.canDrawOverlays(reactContext);
                    hasPermissionScreen = false; // Fallback doesn't have dedicated permission screen
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // For Android 10-13, check if the app can draw over other apps
                // This is often required for full screen intents to work properly
                canUse = Settings.canDrawOverlays(reactContext);
                hasPermissionScreen = false; // No dedicated full screen intent permission screen
            } else {
                // For older versions, assume it's available since the permission is declared in manifest
                canUse = true;
                hasPermissionScreen = false; // No dedicated permission screen
            }
            
            WritableMap result = Arguments.createMap();
            result.putBoolean("canUse", canUse);
            result.putBoolean("hasPermissionScreen", hasPermissionScreen);
            result.putString("message", canUse ? "Full screen intent is available" : "Full screen intent permission not granted");
            
            Log.d(TAG, "canUseFullScreenIntent: " + canUse + ", hasPermissionScreen: " + hasPermissionScreen);
            promise.resolve(result);
        } catch (Exception e) {
            Log.e(TAG, "Error checking full screen intent permission", e);
            promise.reject("ERROR", "Failed to check full screen intent permission", e);
        }
    }

    @ReactMethod
    public void openFullScreenIntentSettings(Promise promise) {
        try {
            Activity currentActivity = getCurrentActivity();
            if (currentActivity == null) {
                promise.reject("ERROR", "No activity available");
                return;
            }

            Intent intent;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14 (API 34) and above - use the new ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT
                intent = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT");
                Uri uri = Uri.fromParts("package", reactContext.getPackageName(), null);
                intent.setData(uri);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // For Android 6.0-13, open app settings
                intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", reactContext.getPackageName(), null);
                intent.setData(uri);
            } else {
                // For older versions, open general app settings
                intent = new Intent(Settings.ACTION_APPLICATION_SETTINGS);
            }

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            currentActivity.startActivity(intent);
            
            Log.d(TAG, "Opened full screen intent settings");
            promise.resolve("Settings opened successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error opening full screen intent settings", e);
            promise.reject("ERROR", "Failed to open settings", e);
        }
    }

    @ReactMethod
    public void requestFullScreenIntentPermission(Promise promise) {
        try {
            Activity currentActivity = getCurrentActivity();
            if (currentActivity == null) {
                promise.reject("ERROR", "No activity available");
                return;
            }

            // Since USE_FULL_SCREEN_INTENT is not a runtime permission that can be requested via dialog,
            // we need to guide the user to settings to enable the necessary permissions
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14 and above - use the new full screen intent settings
                openFullScreenIntentSettings(promise);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // For Android 6.0-13, open settings to enable draw over other apps
                openFullScreenIntentSettings(promise);
            } else {
                // For older versions, permission is typically granted by default
                WritableMap result = Arguments.createMap();
                result.putBoolean("granted", true);
                result.putString("message", "Full screen intent permission granted");
                promise.resolve(result);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error requesting full screen intent permission", e);
            promise.reject("ERROR", "Failed to request permission", e);
        }
    }
} 