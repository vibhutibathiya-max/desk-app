module.exports = {
    project: {
        ios: {},
        android: {
            packageName: 'com.tragofone.app', // Replace 'com.yourprojectname' with your actual package name
        },
    },
    assets: ["./app/assets/fonts/"], // stays the same
};