package com.tragofone.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class IncomingCallNotificationManager {

    private static final String CHANNEL_ID = "call_channel_id";
    private static final String CHANNEL_NAME = "Incoming Calls";
    private static final String TAG = "CallNotification";
    private static final String LANGUAGE_KEY = "_appLanguage";

    private static String getLocalizedString(Context context, String langCode, String key) {
        // Map JavaScript language codes to Android locale codes
        String androidLocaleCode = mapLanguageToLocale(langCode);
        
        Locale locale = new Locale(androidLocaleCode);
        Locale.setDefault(locale);

        Configuration config = new Configuration(context.getResources().getConfiguration());
        config.setLocale(locale);  // this is key

        Context localizedContext = context.createConfigurationContext(config);
        Resources resources = localizedContext.getResources();

        int resId = resources.getIdentifier(key, "string", context.getPackageName());
        if (resId == 0) {
            // fallback to default
            resId = context.getResources().getIdentifier(key, "string", context.getPackageName());
            return context.getString(resId);
        }

        return resources.getString(resId);
    }
    
    private static String mapLanguageToLocale(String appLanguage) {
        switch (appLanguage) {
            case "ar": return "ar";
            case "de": return "de";
            case "du": return "nl"; // JavaScript "du" maps to Android "nl" (Dutch)
            case "fr": return "fr";
            case "gb": return "en-rGB"; // JavaScript "gb" maps to Android "en-rGB" (British English)
            case "he": return "he"; // Hebrew - matches values-he directory
            case "it": return "it";
            case "pt": return "pt-rBR";
            case "ru": return "ru";
            case "tr": return "tr";
            case "zh-cn": return "zh-rCN";
            case "zh-tw": return "zh-rTW";
            default: return "en";
        }
    }

    // Backward-compatible API: default to using Full Screen Intent
    public static void showIncomingCallNotification(
        Context context,
        String callerNumber,
        String uuid,
        String callerName,
        String callerProfilePic,
        String notificationData
    ) {
        showIncomingCallNotification(
            context,
            callerNumber,
            uuid,
            callerName,
            callerProfilePic,
            notificationData,
            true
        );
    }

    // New API: choose whether to use Full Screen Intent or a normal heads-up notification
    public static void showIncomingCallNotification(
        Context context,
        String callerNumber,
        String uuid,
        String callerName,
        String callerProfilePic,
        String notificationData,
        boolean useFullScreenIntent
    ) {
        try {
            Log.d(TAG, "🔔 Showing incoming call notification");

            createNotificationChannel(context);

            // Parse notification data to check if it's a video call
            boolean isVideo = false;
            if (notificationData != null) {
                try {
                    JSONObject data = new JSONObject(notificationData);
                    String isVideoRaw = data.optString("is_video", "'false'");
                    isVideo = "true".equalsIgnoreCase(isVideoRaw.replace("'", "").trim());
                    Log.d(TAG, "📹 Is video call: " + isVideo);
                } catch (JSONException e) {
                    Log.e(TAG, "❌ Error parsing notification data for is_video", e);
                }
            }

            SharedPreferences prefs = context.getSharedPreferences("_appLanguage", Context.MODE_PRIVATE);
            String langCode = prefs.getString("_appLanguage", "en"); // e.g., "fr", "hi", "es"
            Log.d("langCode", "langCode: " + langCode);
            String accept = getLocalizedString(context, langCode, "accept_call");
            Log.d("accept", "accept: " + accept);
            String decline = getLocalizedString(context, langCode, "decline_call");
            Log.d("decline", "decline: " + decline);
            String acceptVideo = getLocalizedString(context, langCode, "accept_video_call");
            Log.d("acceptVideo", "acceptVideo: " + acceptVideo);


            // Intent to launch IncomingCallActivity when tapping notification
            Intent fullScreenIntent = new Intent(context, IncomingCallActivity.class);
            fullScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            fullScreenIntent.putExtra("caller_number", callerNumber);
            fullScreenIntent.putExtra("notification_uuid", uuid);
            fullScreenIntent.putExtra("caller_name", callerName);
            fullScreenIntent.putExtra("caller_profilePic", callerProfilePic);
            fullScreenIntent.putExtra("notification_data", notificationData);

            PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
                context,
                0,
                fullScreenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Accept call action
            Intent acceptIntent = new Intent(context, MainActivity.class);
            acceptIntent.putExtra("notification_data", notificationData);
            acceptIntent.putExtra("call_action", "accept_audio");
            acceptIntent.setAction("accept_audio");
            PendingIntent acceptPendingIntent = PendingIntent.getActivity(
                context,
                1,
                acceptIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Accept video call action (only if is_video is true)
            PendingIntent acceptVideoPendingIntent = null;
            if (isVideo) {
                Intent acceptVideoIntent = new Intent(context, MainActivity.class);
                acceptVideoIntent.putExtra("notification_data", notificationData);
                acceptVideoIntent.putExtra("call_action", "accept_video");
                acceptVideoIntent.setAction("accept_video");
                acceptVideoPendingIntent = PendingIntent.getActivity(
                    context,
                    2,
                    acceptVideoIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
            }

            // Decline call action
            Intent declineIntent = new Intent(context, NotificationActionReceiver.class);
            declineIntent.putExtra("notification_data", notificationData);
            declineIntent.putExtra("call_action", "decline");
            declineIntent.setAction("decline");
            PendingIntent declinePendingIntent = PendingIntent.getBroadcast(
                context,
                3,
                declineIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Delete intent for when notification is dismissed (swiped away)
            Intent deleteIntent = new Intent(context, NotificationDismissReceiver.class);
            deleteIntent.setAction("com.tragofone.app.NOTIFICATION_DISMISSED");
            deleteIntent.putExtra("notification_data", notificationData); // Pass notification data for decline web service
            PendingIntent deletePendingIntent = PendingIntent.getBroadcast(
                context,
                4,
                deleteIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            Uri ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);

            // Build notification with conditional video action and localized strings
            // IMPORTANT: Set vibration pattern directly on notification for battery-restricted mode
            // This ensures vibration works even when channel settings are not applied immediately
            long[] vibrationPattern = new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000};
        
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher) // Replace with your actual icon
                .setContentTitle(callerName != null ? callerName : callerNumber)
                .setContentText(callerNumber)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setColor(Color.GREEN)
                .setAutoCancel(false)
                .setOngoing(true)
                .setVibrate(vibrationPattern) // Set vibration directly on notification for reliability
                // .setSound(ringtoneUri)
                .addAction(new NotificationCompat.Action(
                    android.R.drawable.sym_action_call,
                    accept,
                    acceptPendingIntent
                ));

            // Add video action only if it's a video call
            if (isVideo && acceptVideoPendingIntent != null) {
                notificationBuilder.addAction(new NotificationCompat.Action(
                    android.R.drawable.ic_menu_camera,
                    acceptVideo,
                    acceptVideoPendingIntent
                ));
            }

            notificationBuilder
                .addAction(new NotificationCompat.Action(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    decline,
                    declinePendingIntent
                ))
                .setDeleteIntent(deletePendingIntent); // Handle notification dismissal
                
            if (useFullScreenIntent) {
                notificationBuilder.setFullScreenIntent(fullScreenPendingIntent, true);
            }

            Notification notification = notificationBuilder.build();
            NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            if (notificationManager != null) {
                notificationManager.notify(1001, notification);
            }

        } catch (Exception e) {
            Log.e(TAG, "❌ Failed to show incoming call notification", e);
        }
    }

    private static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;
            
            // Check if channel already exists
            NotificationChannel existingChannel = manager.getNotificationChannel(CHANNEL_ID);
            
            if (existingChannel != null) {
                // Channel exists - only recreate if it has sound enabled (legacy upgrade)
                // DON'T check shouldVibrate() - it may return false due to user settings or timing
                // Vibration is handled directly on notification builder for reliability
                if (existingChannel.getSound() != null) {
                    Log.d(TAG, "⚠️ Existing channel has sound enabled - needs update");
                    try {
                        manager.deleteNotificationChannel(CHANNEL_ID);
                        Log.d(TAG, "✅ Deleted old call channel for recreation");
                    } catch (Exception e) {
                        Log.e(TAG, "❌ Failed to delete channel: " + e.getMessage());
                        return; // Can't recreate, use existing
                    }
                } else {
                    Log.d(TAG, "✅ Call channel exists (no sound) - using existing");
                    return; // Channel is fine, no need to recreate
                }
            }
            
            // Create new channel WITHOUT sound but WITH vibration
            // Sound is handled by MediaPlayer in RingtoneService for dynamic tone switching
            // Vibration is enabled on channel AND on notification for maximum reliability
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Handles incoming call alerts");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setShowBadge(false);
            
            // NO SOUND - MediaPlayer handles audio in RingtoneService
            channel.setSound(null, null);
            // ENABLE vibration on channel
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 1000, 1000, 1000, 1000, 1000, 1000});

            manager.createNotificationChannel(channel);
            Log.d(TAG, "✅ Created call channel (NO sound, WITH vibration)");
        }
    }
}
