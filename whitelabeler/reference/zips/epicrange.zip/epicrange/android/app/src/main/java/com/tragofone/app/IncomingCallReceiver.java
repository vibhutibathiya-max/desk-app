package com.tragofone.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.util.HashMap;
import java.util.Map;

public class IncomingCallReceiver extends BroadcastReceiver {

    private static final String TAG = "IncomingCallReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "📲 Incoming call broadcast received");

        String callerNumber = intent.getStringExtra("caller_number");
        String notificationUuid = intent.getStringExtra("notification_uuid");
        String callerName = intent.getStringExtra("caller_name");
        String callerProfilePic = intent.getStringExtra("caller_profilePic");
        String notificationData = intent.getStringExtra("notification_data");

        Log.d(TAG, "callerNumber: " + callerNumber);
        Log.d(TAG, "callerName: " + callerName);
        Log.d(TAG, "profilePic: " + callerProfilePic);
        Log.d(TAG, "notificationData: " + notificationData);
        Log.d(TAG, "notificationUuid: " + notificationUuid);

        IncomingCallNotificationManager.showIncomingCallNotification(
                context,
                callerName,
                callerNumber,
                callerProfilePic,
                notificationUuid,
                notificationData
        );

    }
}
