package com.tragofone.app;

import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.modules.core.DeviceEventManagerModule;

public class CallEventModule extends ReactContextBaseJavaModule {

    private static ReactApplicationContext reactContext;

    public CallEventModule(ReactApplicationContext context) {
        super(context);
        reactContext = context;
    }

    @NonNull
    @Override
    public String getName() {
        return "CallEventModule"; // JS side will use this
    }

    public static void emitEventToJS(String eventName, WritableMap params) {
        if (reactContext != null) {
            if (reactContext.hasActiveCatalystInstance()) {
                Log.e("CallEventModule", "📤 Emitting event to JS: " + eventName);
                reactContext
                    .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                    .emit(eventName, params);
            } else {
                Log.e("CallEventModule", "⏳ ReactContext not ready, retrying in 100ms");
                // Retry after a short delay
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                    if (reactContext != null && reactContext.hasActiveCatalystInstance()) {
                        Log.e("CallEventModule", "📤 Retry: Emitting event to JS: " + eventName);
                        reactContext
                            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                            .emit(eventName, params);
                    } else {
                        Log.e("CallEventModule", "❌ ReactContext still not ready after retry");
                    }
                }, 100);
            }
        } else {
            Log.e("CallEventModule", "❌ ReactContext is null");
        }
    }

    // Required for NativeEventEmitter
    @ReactMethod public void addListener(String eventName) {}
    @ReactMethod public void removeListeners(Integer count) {}
    
    /**
     * Send broadcast to stop ringing service
     */
    @ReactMethod
    public void sendStopRingingBroadcast() {
        try {
            Log.d("CallEventModule", "📡 Sending stop ringing broadcast");
            Intent stopRingingIntent = new Intent("com.tragofone.app.ACTION_STOP_RINGING");
            stopRingingIntent.setPackage(reactContext.getPackageName());
            reactContext.sendBroadcast(stopRingingIntent);
            Log.d("CallEventModule", "✅ Stop ringing broadcast sent successfully");
        } catch (Exception e) {
            Log.e("CallEventModule", "❌ Error sending stop ringing broadcast: " + e.getMessage());
        }
    }
}
