package com.tragofone.app;

import com.facebook.react.bridge.JavaScriptModule;

public interface CallStateChangeActionModule extends JavaScriptModule {
    void callStateChanged(String state);
}
