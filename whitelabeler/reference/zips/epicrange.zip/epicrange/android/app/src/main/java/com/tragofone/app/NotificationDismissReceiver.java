package com.tragofone.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

public class NotificationDismissReceiver extends BroadcastReceiver {
    private static final String TAG = "NotificationDismiss";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "📱 Notification dismissed - stopping ringtone");
        Log.d(TAG, "Action received: " + intent.getAction());
        
        final PendingResult pendingResult = goAsync(); // important!
        
        new Thread(() -> {
            try {
                // Send broadcast to stop ringtone service
                Intent stopRingingIntent = new Intent("com.tragofone.app.ACTION_STOP_RINGING");
                context.sendBroadcast(stopRingingIntent);
                Log.d(TAG, "✅ Stop ringtone broadcast sent");
                
                // Also stop the ringtone service directly if it's running
                Intent stopServiceIntent = new Intent(context, RingtoneService.class);
                context.stopService(stopServiceIntent);
                Log.d(TAG, "✅ Ringtone service stop requested");
                
                // Log the dismissal for debugging
                Log.d(TAG, "📱 Incoming call notification was dismissed by user");
                
                // Get notification data from the intent to extract decline UUID
                String notificationData = intent.getStringExtra("notification_data");
                if (notificationData != null && !notificationData.isEmpty()) {
                    try {
                        JSONObject json = new JSONObject(notificationData);
                        String declineUuid = json.optString("decline_uuid", "");
                        
                        if (!declineUuid.isEmpty()) {
                            Log.d(TAG, "🔴 Calling decline web service with UUID: " + declineUuid);
                            
                            // Call the decline web service
                            WebServiceHelper.declineCall(context, declineUuid, new WebServiceHelper.WebServiceCallback() {
                                @Override
                                public void onSuccess(String response) {
                                    Log.d(TAG, "✅ Decline call web service successful: " + response);
                                    pendingResult.finish(); // Finish after success
                                }

                                @Override
                                public void onError(String error) {
                                    Log.e(TAG, "❌ Decline call web service failed: " + error);
                                    pendingResult.finish(); // Finish after error
                                }
                            });
                        } else {
                            Log.w(TAG, "⚠️ No decline UUID found in notification data");
                            pendingResult.finish();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "❌ Error parsing notification data JSON: " + e.getMessage(), e);
                        pendingResult.finish();
                    }
                } else {
                    Log.w(TAG, "⚠️ No notification data found for decline web service call");
                    pendingResult.finish();
                }
                
            } catch (Exception e) {
                Log.e(TAG, "❌ Error in notification dismiss handling: " + e.getMessage(), e);
                pendingResult.finish(); // Always finish
            }
        }).start();
    }
}
