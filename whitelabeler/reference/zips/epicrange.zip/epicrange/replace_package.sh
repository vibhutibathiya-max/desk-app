#!/bin/bash

# Base directory (current folder)
BASE_DIR="."

# Old and new package/bundle ID inputs (edit these manually before running the script)
OLD_PACKAGE="com.tragofone.app"
NEW_PACKAGE=""

# Optional App Name change (leave NEW_NAME empty to skip)
OLD_NAME="Tragofone"
NEW_NAME=""

# Optional SSO scheme change (leave NEW_SSO_SCHEME empty to skip)
OLD_SSO_SCHEME="tragofonesso"
NEW_SSO_SCHEME=""

# Optional Android gradient colors (leave empty to skip)
# Suggested defaults:
#   gradient_light_start  -> #6533E2
#   gradient_light_center -> #7349DE
#   gradient_light_end    -> #1F97EF
NEW_GRADIENT_LIGHT_START=""
NEW_GRADIENT_LIGHT_CENTER=""
NEW_GRADIENT_LIGHT_END=""
NEW_PROFILE_BACKGROUND_COLOR=""


# Optional Android version updates (leave empty to skip)
NEW_VERSION_CODE=""
NEW_VERSION_NAME=""


echo "🔍 Replacing '$OLD_PACKAGE' → '$NEW_PACKAGE' inside $BASE_DIR ..."

######  ----------  HERE WE WILL UPDATE BUNDLE ID  ----------  #####
# Replace bundle ID in common text-based files (incl. swift, xcconfig)
find "$BASE_DIR" -type f \
  \( -name "*.java" -o -name "*.kt" -o -name "*.xml" -o -name "*.gradle" -o -name "*.json" -o -name "*.js" -o -name "*.txt" -o -name "*.properties" -o -name "*.md" -o -name "*.plist" -o -name "*.patch" -o -name "*.swift" -o -name "*.xcconfig" \) \
  -exec sed -i.bak "s|$OLD_PACKAGE|$NEW_PACKAGE|g" {} +

######  ----------  HERE WE WILL UPDATE SSO SCHEME PROTOCOL  ----------  #####
# Targeted SSO scheme updates (only if NEW_SSO_SCHEME is provided)
if [ -n "$NEW_SSO_SCHEME" ]; then
  echo "🔗 Updating SSO scheme '$OLD_SSO_SCHEME' → '$NEW_SSO_SCHEME' ..."

  # Android: AndroidManifest.xml -> android:scheme="tragofonesso"
  ANDROID_MANIFEST="$BASE_DIR/android/app/src/main/AndroidManifest.xml"
  if [ -f "$ANDROID_MANIFEST" ]; then
    sed -i.bak -E "s|(android:scheme=\")$OLD_SSO_SCHEME(\")|\\1$NEW_SSO_SCHEME\\2|g" "$ANDROID_MANIFEST"
    rm -f "$ANDROID_MANIFEST.bak"
    echo "   - AndroidManifest.xml SSO scheme updated"
  fi

  # iOS: TragofoneNew/Info.plist -> <string>tragofonesso</string>
  IOS_INFO_PLIST="$BASE_DIR/ios/TragofoneNew/Info.plist"
  if [ -f "$IOS_INFO_PLIST" ]; then
    sed -i.bak -E "s|(>)\s*$OLD_SSO_SCHEME\s*(<)|\\1$NEW_SSO_SCHEME\\2|g" "$IOS_INFO_PLIST"
    rm -f "$IOS_INFO_PLIST.bak"
    echo "   - iOS Info.plist SSO scheme updated"
  fi
fi

#####  ----------  HERE WE WILL UPDATE ANDROID SIDE GRADIENT COLORS FOR CALL SCREEN  ----------  #####
# Targeted Android color updates (only if provided)
COLORS_XML="$BASE_DIR/android/app/src/main/res/values/colors.xml"
if [ -f "$COLORS_XML" ]; then
  if [ -n "$NEW_GRADIENT_LIGHT_START" ]; then
    sed -i.bak -E "s|(name=\"gradient_light_start\">)[^<]+(</color>)|\\1$NEW_GRADIENT_LIGHT_START\\2|" "$COLORS_XML"
    echo "   - Updated gradient_light_start in colors.xml"
  fi
  if [ -n "$NEW_GRADIENT_LIGHT_CENTER" ]; then
    sed -i.bak -E "s|(name=\"gradient_light_center\">)[^<]+(</color>)|\\1$NEW_GRADIENT_LIGHT_CENTER\\2|" "$COLORS_XML"
    echo "   - Updated gradient_light_center in colors.xml"
  fi
  if [ -n "$NEW_GRADIENT_LIGHT_END" ]; then
    sed -i.bak -E "s|(name=\"gradient_light_end\">)[^<]+(</color>)|\\1$NEW_GRADIENT_LIGHT_END\\2|" "$COLORS_XML"
    echo "   - Updated gradient_light_end in colors.xml"
  fi
  if [ -n "$NEW_PROFILE_BACKGROUND_COLOR" ]; then
    sed -i.bak -E "s|(name=\"profileBackgroundColor\">)[^<]+(</color>)|\\1$NEW_PROFILE_BACKGROUND_COLOR\\2|" "$COLORS_XML"
    echo "   - Updated profileBackgroundColor in colors.xml"
  fi
  # Clean up colors.xml backup if created
  rm -f "$COLORS_XML.bak"
fi

#####  ----------  HERE WE WILL UPDATE ANDROID VERSION IN BUILD.GRADLE  ----------  #####
# Targeted Android version updates (only if provided)
BUILD_GRADLE="$BASE_DIR/android/app/build.gradle"
if [ -f "$BUILD_GRADLE" ]; then
  if [ -n "$NEW_VERSION_CODE" ]; then
    sed -i.bak -E "s|(versionCode )[0-9]+|\\1$NEW_VERSION_CODE|" "$BUILD_GRADLE"
    echo "   - Updated versionCode in build.gradle"
  fi
  if [ -n "$NEW_VERSION_NAME" ]; then
    sed -i.bak -E "s|(versionName \")[^\"]+(\")|\\1$NEW_VERSION_NAME\\2|" "$BUILD_GRADLE"
    echo "   - Updated versionName in build.gradle"
  fi
  # Clean up build.gradle backup if created
  rm -f "$BUILD_GRADLE.bak"
fi

######  ----------  HERE WE WILL UPDATE APP NAME  ----------  #####
# Targeted App Name updates (only if NEW_NAME is provided)
if [ -n "$NEW_NAME" ]; then
  echo "📝 Updating app name '$OLD_NAME' → '$NEW_NAME' ..."

  # 1) Android: strings.xml -> app_name
  ANDROID_STRINGS="$BASE_DIR/android/app/src/main/res/values/strings.xml"
  if [ -f "$ANDROID_STRINGS" ]; then
    sed -i.bak -E "s|(\<string name=\"app_name\"\>)[^<]*(\</string\>)|\\1$NEW_NAME\\2|" "$ANDROID_STRINGS"
    rm -f "$ANDROID_STRINGS.bak"
    echo "   - Android app_name updated"
  fi

  # 2) JS: GlobalDefines.js -> const APP_NAME = "..."
  GLOBAL_DEFINES_JS="$BASE_DIR/app/utils/GlobalDefines.js"
  if [ -f "$GLOBAL_DEFINES_JS" ]; then
    sed -i.bak -E "s|^const APP_NAME = \".*\";|const APP_NAME = \"$NEW_NAME\";|" "$GLOBAL_DEFINES_JS"
    rm -f "$GLOBAL_DEFINES_JS.bak"
    echo "   - GlobalDefines.js APP_NAME updated"
  fi

  # 3) iOS: brandng.xcconfig -> APP_DISPLAY_NAME = ...
  IOS_BRAND_XCCONFIG="$BASE_DIR/ios/brandng.xcconfig"
  if [ -f "$IOS_BRAND_XCCONFIG" ]; then
    NAME_VAL="$NEW_NAME"
    sed -i.bak -E "s|^(APP_DISPLAY_NAME[[:space:]]*=[[:space:]]*).*$|\\1$NAME_VAL|" "$IOS_BRAND_XCCONFIG"
    rm -f "$IOS_BRAND_XCCONFIG.bak"
    echo "   - iOS APP_DISPLAY_NAME updated"
  fi
fi

# Remove backup files
find "$BASE_DIR" -type f -name "*.bak" -delete

echo "✅ Replacement done"