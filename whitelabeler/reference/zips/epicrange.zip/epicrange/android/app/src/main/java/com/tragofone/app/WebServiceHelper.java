package com.tragofone.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class WebServiceHelper {
    private static final String TAG = "WebServiceHelper";
    private static final Executor executor = Executors.newCachedThreadPool();
    private static final AtomicBoolean isRefreshingToken = new AtomicBoolean(false);
    
    public interface WebServiceCallback {
        void onSuccess(String response);
        void onError(String error);
    }
    
    public interface TokenRefreshCallback {
        void onTokenRefreshed(String newToken);
        void onTokenRefreshFailed(String error);
    }
    
    // private static String makeHttpRequestWithTokenRefresh(Context context, String urlString, String token, WebServiceCallback callback) throws Exception {
    //     try {
    //         return makeHttpRequest(urlString, token);
    //     } catch (Exception e) {
    //         if (e.getMessage() != null && e.getMessage().contains("HTTP 401")) {
    //             Log.d(TAG, "Received 401 error, attempting token refresh...");
                
    //             // Try to refresh token
    //             String newToken = refreshToken(context);
    //             if (newToken != null) {
    //                 Log.d(TAG, "Token refreshed successfully, retrying request...");
    //                 // Retry the request with new token
    //                 return makeHttpRequest(urlString, newToken);
    //             } else {
    //                 Log.e(TAG, "Token refresh failed");
    //                 callback.onError("Token refresh failed");
    //                 return null;
    //             }
    //         } else {
    //             // Re-throw other exceptions
    //             throw e;
    //         }
    //     }
    // }
    
    private static String makeHttpRequest(String urlString, String token) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        try {
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            
            // Add headers
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            if (token != null && !token.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + token);
            }
            
            int responseCode = connection.getResponseCode();
            Log.d(TAG, "Response code: " + responseCode);
            
            BufferedReader reader;
            if (responseCode >= 200 && responseCode < 300) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            } else {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            }
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            
            if (responseCode >= 200 && responseCode < 300) {
                return response.toString();
            } else {
                throw new Exception("HTTP " + responseCode + ": " + response.toString());
            }
            
        } finally {
            connection.disconnect();
        }
    }
    
    private static String makeHttpPostRequestWithTokenRefresh(Context context, String urlString, String token, String jsonBody, WebServiceCallback callback) throws Exception {
        try {
            return makeHttpPostRequest(urlString, token, jsonBody);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains("HTTP 401")) {
                Log.d(TAG, "Received 401 error, attempting token refresh...");
                
                // Try to refresh token
                String newToken = refreshToken(context);
                if (newToken != null) {
                    Log.d(TAG, "Token refreshed successfully, retrying POST request...");
                    // Retry the request with new token
                    return makeHttpPostRequest(urlString, newToken, jsonBody);
                } else {
                    Log.e(TAG, "Token refresh failed");
                    callback.onError("Token refresh failed");
                    return null;
                }
            } else {
                // Re-throw other exceptions
                throw e;
            }
        }
    }
    
    private static String makeHttpPostRequest(String urlString, String token, String jsonBody) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        try {
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setDoOutput(true);
            
            // Add headers
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            if (token != null && !token.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + token);
            }
            
            // Write JSON body
            try (OutputStream os = connection.getOutputStream();
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8))) {
                writer.write(jsonBody);
                writer.flush();
            }
            
            int responseCode = connection.getResponseCode();
            Log.d(TAG, "POST Response code: " + responseCode);
            
            BufferedReader reader;
            if (responseCode >= 200 && responseCode < 300) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            } else {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            }
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            
            if (responseCode >= 200 && responseCode < 300) {
                return response.toString();
            } else {
                throw new Exception("HTTP " + responseCode + ": " + response.toString());
            }
            
        } finally {
            connection.disconnect();
        }
    }
    
    /**
     * Refreshes the token when 401 error occurs
     * @param context Application context
     * @return New token if successful, null if failed
     */
    private static String refreshToken(Context context) {
        if (isRefreshingToken.get()) {
            Log.d(TAG, "Token refresh already in progress, waiting...");
            // Wait for the current refresh to complete
            int maxWaitTime = 10000; // 10 seconds
            int waitTime = 0;
            while (isRefreshingToken.get() && waitTime < maxWaitTime) {
                try {
                    Thread.sleep(100);
                    waitTime += 100;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
            
            // Check if token was refreshed by another thread
            SharedPreferences prefs = context.getSharedPreferences("CRM_PREFS", Context.MODE_PRIVATE);
            String newToken = prefs.getString("_crmUserID", null);
            if (newToken != null && !newToken.isEmpty()) {
                return newToken;
            }
        }
        
        // Set refresh flag
        if (!isRefreshingToken.compareAndSet(false, true)) {
            return null;
        }
        
        try {
            Log.d(TAG, "Starting token refresh...");
            
            // Read refresh token from preferences
            SharedPreferences prefs = context.getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
            String refreshToken = prefs.getString("_accessToken", null);
            String baseUrl = prefs.getString("baseUrl", null);
            
            if (refreshToken == null || refreshToken.isEmpty()) {
                Log.e(TAG, "No refresh token found in preferences");
                return null;
            }
            
            if (baseUrl == null || baseUrl.isEmpty()) {
                Log.e(TAG, "No base URL found in preferences");
                return null;
            }
            
            // Construct refresh URL (you may need to adjust this based on your API)
            String refreshUrl = baseUrl.endsWith("/") ? baseUrl + "auth/refresh" : baseUrl + "/auth/refresh";
            
            // Create refresh request body
            JSONObject refreshBody = new JSONObject();
            refreshBody.put("refresh_token", refreshToken);
            
            Log.d(TAG, "Making token refresh request to: " + refreshUrl);
            
            // Make refresh request
            String response = makeHttpPostRequest(refreshUrl, null, refreshBody.toString());
            
            // Parse response to get new token
            JSONObject responseJson = new JSONObject(response);
            String newAccessToken = responseJson.optString("access_token");
            String newRefreshToken = responseJson.optString("refresh_token");
            
            if (newAccessToken != null && !newAccessToken.isEmpty()) {
                Log.d(TAG, "Token refresh successful");
                
                // Update tokens in preferences
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("_accessToken", newAccessToken);
                if (newRefreshToken != null && !newRefreshToken.isEmpty()) {
                    editor.putString("_refreshToken", newRefreshToken);
                }
                editor.apply();
                
                return newAccessToken;
            } else {
                Log.e(TAG, "No access token in refresh response");
                return null;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error refreshing token", e);
            return null;
        } finally {
            // Clear refresh flag
            isRefreshingToken.set(false);
        }
    }
    
    /**
     * Manually refresh token (can be called from outside)
     * @param context Application context
     * @param callback Callback to handle refresh result
     */
    public static void refreshTokenManually(Context context, TokenRefreshCallback callback) {
        CompletableFuture.runAsync(() -> {
            String newToken = refreshToken(context);
            if (newToken != null) {
                callback.onTokenRefreshed(newToken);
            } else {
                callback.onTokenRefreshFailed("Token refresh failed");
            }
        }, executor);
    }
    
    /**
     * Updates the token in preferences (called from outside when token is updated)
     * @param context Application context
     * @param newToken New token to save
     * @param refreshToken New refresh token (optional)
     */
    public static void updateToken(Context context, String newToken, String refreshToken) {
        SharedPreferences prefs = context.getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("_accessToken", newToken);
        if (refreshToken != null && !refreshToken.isEmpty()) {
            editor.putString("_refreshToken", refreshToken);
        }
        editor.apply();
        Log.d(TAG, "Token updated in preferences");
    }
    
    /**
     * Makes a call control request to decline a call
     * @param context Application context
     * @param declineUuid UUID of the call to decline
     * @param callback Callback to handle response
     */
    public static void declineCall(Context context, String declineUuid, WebServiceCallback callback) {
        CompletableFuture.runAsync(() -> {
            try {
                // Read URL and token from preferences
                SharedPreferences prefs = context.getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
                String baseUrl = prefs.getString("baseUrl", null);
                String token = prefs.getString("_accessToken", null);
                
                if (baseUrl == null || baseUrl.isEmpty()) {
                    callback.onError("Base URL not found in preferences");
                    return;
                }
                
                if (declineUuid == null || declineUuid.isEmpty()) {
                    callback.onError("Decline UUID cannot be null or empty");
                    return;
                }
                
                // Construct the call_control endpoint URL
                String callControlUrl = baseUrl.endsWith("/") ? baseUrl + "call_control" : baseUrl + "/call_control";
                
                // Create command params with proper URL encoding
                String commandParams = declineUuid + " DECLINE";
                // URL encode the command params and replace + with %20 for proper URL encoding
                String encodedCommandParams = java.net.URLEncoder.encode(commandParams, StandardCharsets.UTF_8.toString()).replace("+", "%20");
                
                // Create JSON body for the request
                JSONObject requestBody = new JSONObject();
                requestBody.put("command", "uuid_kill");
                requestBody.put("command_params", encodedCommandParams);
                
                Log.d(TAG, "Making call control request to: " + callControlUrl);
                Log.d(TAG, "Command params: " + commandParams);
                Log.d(TAG, "Encoded command params: " + encodedCommandParams);
                Log.d(TAG, "Expected format: " + declineUuid + "%20DECLINE");
                
                // Make the HTTP POST request with token refresh handling
                String response = makeHttpPostRequestWithTokenRefresh(context, callControlUrl, token, requestBody.toString(), callback);
                if (response != null) {
                    callback.onSuccess(response);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error making call control request", e);
                callback.onError("Error: " + e.getMessage());
            }
        }, executor);
    }
    
    /**
     * Makes a generic call control request
     * @param context Application context
     * @param command Command to execute (e.g., "uuid_kill")
     * @param commandParams Command parameters (will be URL encoded)
     * @param callback Callback to handle response
     */
    public static void makeCallControlRequest(Context context, String command, String commandParams, WebServiceCallback callback) {
        CompletableFuture.runAsync(() -> {
            try {
                // Read URL and token from preferences
                SharedPreferences prefs = context.getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
                String baseUrl = prefs.getString("baseUrl", null);
                String token = prefs.getString("_crmUserID", null);
                
                if (baseUrl == null || baseUrl.isEmpty()) {
                    callback.onError("Base URL not found in preferences");
                    return;
                }
                
                if (command == null || command.isEmpty()) {
                    callback.onError("Command cannot be null or empty");
                    return;
                }
                
                // Construct the call_control endpoint URL
                String callControlUrl= baseUrl.endsWith("/") ? baseUrl + "call_control" : baseUrl + "/call_control";
                
                // URL encode the command params and replace + with %20 for proper URL encoding
                String encodedCommandParams = "";
                if (commandParams != null && !commandParams.isEmpty()) {
                    encodedCommandParams = java.net.URLEncoder.encode(commandParams, StandardCharsets.UTF_8.toString()).replace("+", "%20");
                }
                
                // Create JSON body for the request
                JSONObject requestBody = new JSONObject();
                requestBody.put("command", command);
                requestBody.put("command_params", encodedCommandParams);
                
                Log.d(TAG, "Making call control request to: " + callControlUrl);
                Log.d(TAG, "Command: " + command);
                Log.d(TAG, "Command params: " + commandParams);
                Log.d(TAG, "Encoded command params: " + encodedCommandParams);
                
                // Make the HTTP POST request with token refresh handling
                String response = makeHttpPostRequestWithTokenRefresh(context, callControlUrl, token, requestBody.toString(), callback);
                if (response != null) {
                    callback.onSuccess(response);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error making call control request", e);
                callback.onError("Error: " + e.getMessage());
            }
        }, executor);
    }
} 