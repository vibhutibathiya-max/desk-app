package com.tragofone.app;

public interface ReactCallBackListener {
    void onUIModeChanged();
}
