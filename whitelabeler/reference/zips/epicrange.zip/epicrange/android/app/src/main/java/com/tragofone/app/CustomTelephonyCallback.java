package com.tragofone.app;

import android.os.Build;
import android.telephony.TelephonyCallback;
import android.util.Log;

import androidx.annotation.RequiresApi;

@RequiresApi(api = Build.VERSION_CODES.S)
public class CustomTelephonyCallback extends TelephonyCallback implements TelephonyCallback.CallStateListener {

    private final PhoneCallStateCallback callback;

    public CustomTelephonyCallback(PhoneCallStateCallback callStateCallback){
        this.callback = callStateCallback;
    }

    @Override
    public void onCallStateChanged(int state) {
        Log.d("ReactNativeJS", "PhoneState onCallStateChanged: " + state);
        this.callback.onPhoneCallStateChange(state);
    }

    interface PhoneCallStateCallback {
        void onPhoneCallStateChange(int state);
    }
}
