package com.tragofone.app;

import static android.app.UiModeManager.MODE_NIGHT_NO;

import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.events.RCTEventEmitter;

public class CustomView extends LinearLayout implements View.OnClickListener, View.OnLongClickListener {

    private Context context;
    private String message = "NOT SET";
    private ConstraintLayout cnstrntDigit1;
    private ConstraintLayout cnstrntDigit2;
    private ConstraintLayout cnstrntDigit3;
    private ConstraintLayout cnstrntDigit4;
    private ConstraintLayout cnstrntDigit5;
    private ConstraintLayout cnstrntDigit6;
    private ConstraintLayout cnstrntDigit7;
    private ConstraintLayout cnstrntDigit8;
    private ConstraintLayout cnstrntDigit9;
    private ConstraintLayout cnstrntDigit0;
    private ConstraintLayout cnstrntDigitStar;
    private ConstraintLayout cnstrntDigitPound;

    private TextView txtDigit1;
    private TextView txtDigit2;
    private TextView txtDigit3;
    private TextView txtDigit4;
    private TextView txtDigit5;
    private TextView txtDigit6;
    private TextView txtDigit7;
    private TextView txtDigit8;
    private TextView txtDigit9;
    private TextView txtDigit0;
    private TextView txtDigitStar;
    private TextView txtDigitPound;
    private TextView txtAlphabetDigit2;
    private TextView txtAlphabetDigit3;
    private TextView txtAlphabetDigit4;
    private TextView txtAlphabetDigit5;
    private TextView txtAlphabetDigit6;
    private TextView txtAlphabetDigit7;
    private TextView txtAlphabetDigit8;
    private TextView txtAlphabetDigit9;
    private TextView txtAlphabetDigit0;

    public CustomView(Context context, String message) {
        super(context);
        this.context = context;
        this.message = message;
        init();
    }

    private BroadcastReceiver receiver;
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Log.d("MyCustomView", "Received data BroadcastReceiver: " + MainActivity.isDarkMode);
        // changeColorResources(MainActivity.isDarkMode);
    }


    public void init() {
        inflate(this.context, R.layout.customdialpad_layout, this);
        // Force LTR layout direction for dialpad regardless of system RTL setting
        // Numeric keypads should always display in standard LTR order (1,2,3 from left to right)
        setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        //This can be viewed in Android Studio's Log Cat.
        Log.i("Inflated XML", "ANDROID_SAMPLE_UI");
        initViews();
        setListeners();

    }

    private void setListeners() {
        cnstrntDigit1.setOnClickListener(this);
        cnstrntDigit2.setOnClickListener(this);
        cnstrntDigit3.setOnClickListener(this);
        cnstrntDigit4.setOnClickListener(this);
        cnstrntDigit5.setOnClickListener(this);
        cnstrntDigit6.setOnClickListener(this);
        cnstrntDigit7.setOnClickListener(this);
        cnstrntDigit8.setOnClickListener(this);
        cnstrntDigit9.setOnClickListener(this);
        cnstrntDigit0.setOnClickListener(this);
        cnstrntDigitStar.setOnClickListener(this);
        cnstrntDigitPound.setOnClickListener(this);
        cnstrntDigit0.setOnLongClickListener(this);

    }

    private void initViews() {
        cnstrntDigit1 = findViewById(R.id.cnstrnt_digit_1);
        cnstrntDigit2 = findViewById(R.id.cnstrnt_digit_2);
        cnstrntDigit3 = findViewById(R.id.cnstrnt_digit_3);
        cnstrntDigit4 = findViewById(R.id.cnstrnt_digit_4);
        cnstrntDigit5 = findViewById(R.id.cnstrnt_digit_5);
        cnstrntDigit6 = findViewById(R.id.cnstrnt_digit_6);
        cnstrntDigit7 = findViewById(R.id.cnstrnt_digit_7);
        cnstrntDigit8 = findViewById(R.id.cnstrnt_digit_8);
        cnstrntDigit9 = findViewById(R.id.cnstrnt_digit_9);
        cnstrntDigit0 = findViewById(R.id.cnstrnt_digit_0);
        cnstrntDigitStar = findViewById(R.id.cnstrnt_digit_star);
        cnstrntDigitPound = findViewById(R.id.cnstrnt_digit_pound);

        txtDigit1 = findViewById(R.id.txt_digit_1);
        txtDigit2 = findViewById(R.id.txt_digit_2);
        txtDigit3 = findViewById(R.id.txt_digit_3);
        txtDigit4 = findViewById(R.id.txt_digit_4);
        txtDigit5 = findViewById(R.id.txt_digit_5);
        txtDigit6 = findViewById(R.id.txt_digit_6);
        txtDigit7 = findViewById(R.id.txt_digit_7);
        txtDigit8 = findViewById(R.id.txt_digit_8);
        txtDigit9 = findViewById(R.id.txt_digit_9);
        txtDigit0 = findViewById(R.id.txt_digit_0);
        txtDigitStar = findViewById(R.id.txt_digit_star);
        txtDigitPound = findViewById(R.id.txt_digit_pound);

        txtAlphabetDigit2 = findViewById(R.id.txt_alphabet_digit_2);
        txtAlphabetDigit3 = findViewById(R.id.txt_alphabet_digit_3);
        txtAlphabetDigit4 = findViewById(R.id.txt_alphabet_digit_4);
        txtAlphabetDigit5 = findViewById(R.id.txt_alphabet_digit_5);
        txtAlphabetDigit6 = findViewById(R.id.txt_alphabet_digit_6);
        txtAlphabetDigit7 = findViewById(R.id.txt_alphabet_digit_7);
        txtAlphabetDigit8 = findViewById(R.id.txt_alphabet_digit_8);
        txtAlphabetDigit9 = findViewById(R.id.txt_alphabet_digit_9);
        txtAlphabetDigit0 = findViewById(R.id.txt_alphabet_digit_0);
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * This will send a callback when the UI mode is changed to Dark mode or ViceVersa.
     */
//     @Override
//     protected void onConfigurationChanged(Configuration newConfig) {
//         super.onConfigurationChanged(newConfig);
// //        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
// //            changeColorResources();
// //        }
//     }

    @Override
    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        boolean isDarkMode = (newConfig.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        // changeColorResources(isDarkMode);
    }

    /**
     * This Method will toggle the shape resource and colors when UI mode is Changed.
     */
    // public void changeColorResources(Boolean enableNightMode) {
    //     Log.i("MyCustomView", "changeColorResources "+enableNightMode);
    //     UiModeManager uiModeManager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
    //     int drawableRes = enableNightMode ? R.drawable.button_background_dark : R.drawable.button_background;
    //     cnstrntDigit1.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit2.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit3.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit4.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit5.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit6.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit7.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit8.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit9.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigit0.setBackground(ContextCompat.getDrawable(context,drawableRes));
    //     cnstrntDigitStar.setBackground(ContextCompat.getDrawable(context, drawableRes));
    //     cnstrntDigitPound.setBackground(ContextCompat.getDrawable(context, drawableRes));

    //     txtDigit1.setTextAppearance(R.style.numpad_digit);
    //     txtDigit2.setTextAppearance(R.style.numpad_digit);
    //     txtDigit3.setTextAppearance(R.style.numpad_digit);
    //     txtDigit4.setTextAppearance(R.style.numpad_digit);
    //     txtDigit5.setTextAppearance(R.style.numpad_digit);
    //     txtDigit6.setTextAppearance(R.style.numpad_digit);
    //     txtDigit7.setTextAppearance(R.style.numpad_digit);
    //     txtDigit8.setTextAppearance(R.style.numpad_digit);
    //     txtDigit9.setTextAppearance(R.style.numpad_digit);
    //     txtDigit0.setTextAppearance(R.style.numpad_digit);
    //     txtDigitStar.setTextAppearance(R.style.numpad_digit);
    //     txtDigitPound.setTextAppearance(R.style.numpad_digit);

    //     txtAlphabetDigit2.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit3.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit4.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit5.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit6.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit7.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit8.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit9.setTextAppearance(R.style.numpad_alphabet);
    //     txtAlphabetDigit0.setTextAppearance(R.style.numpad_alphabet);
    // }

    public void changeColorResources(Boolean enableNightMode) {
    Log.i("MyCustomView", "changeColorResources " + enableNightMode);

    int drawableRes = enableNightMode ? R.drawable.button_background_dark : R.drawable.button_background;
    int digitStyle = enableNightMode ? R.style.numpad_digit_dark : R.style.numpad_digit_light;
    int alphabetStyle = enableNightMode ? R.style.numpad_alphabet_dark : R.style.numpad_alphabet_light;

    cnstrntDigit0.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit1.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit2.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit3.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit4.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit5.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit6.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit7.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit8.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigit9.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigitStar.setBackground(ContextCompat.getDrawable(context, drawableRes));
    cnstrntDigitPound.setBackground(ContextCompat.getDrawable(context, drawableRes));

    txtDigit0.setTextAppearance(digitStyle);
    txtDigit1.setTextAppearance(digitStyle);
    txtDigit2.setTextAppearance(digitStyle);
    txtDigit3.setTextAppearance(digitStyle);
    txtDigit4.setTextAppearance(digitStyle);
    txtDigit5.setTextAppearance(digitStyle);
    txtDigit6.setTextAppearance(digitStyle);
    txtDigit7.setTextAppearance(digitStyle);
    txtDigit8.setTextAppearance(digitStyle);
    txtDigit9.setTextAppearance(digitStyle);
    txtDigitStar.setTextAppearance(digitStyle);
    txtDigitPound.setTextAppearance(digitStyle);

    txtAlphabetDigit0.setTextAppearance(alphabetStyle);
    txtAlphabetDigit2.setTextAppearance(alphabetStyle);
    txtAlphabetDigit3.setTextAppearance(alphabetStyle);
    txtAlphabetDigit4.setTextAppearance(alphabetStyle);
    txtAlphabetDigit5.setTextAppearance(alphabetStyle);
    txtAlphabetDigit6.setTextAppearance(alphabetStyle);
    txtAlphabetDigit7.setTextAppearance(alphabetStyle);
    txtAlphabetDigit8.setTextAppearance(alphabetStyle);
    txtAlphabetDigit9.setTextAppearance(alphabetStyle);
}


    //PART 3: Added Receive Event.
    public void callNativeEvent(String buttonNumber) {
        Log.i("Call Native Event", "ANDROID_SAMPLE_UI");
        WritableMap event = Arguments.createMap();
        event.putString("customNativeEventMessage", buttonNumber); //Emmitting an event to Javascript

        //Create a listener where that emits/send the text to JS when action is taken.
        ReactContext reactContext = (ReactContext) getContext();
        reactContext.getJSModule(RCTEventEmitter.class).receiveEvent(
                getId(),
                "nativeClick",    //name has to be same as getExportedCustomDirectEventTypeConstants in MyCustomReactViewManager
                event);
    }

    @Override
public void onClick(View v) {
    int id = v.getId();
    if (id == R.id.cnstrnt_digit_1) {
        callNativeEvent("1");
    } else if (id == R.id.cnstrnt_digit_2) {
        callNativeEvent("2");
    } else if (id == R.id.cnstrnt_digit_3) {
        callNativeEvent("3");
    } else if (id == R.id.cnstrnt_digit_4) {
        callNativeEvent("4");
    } else if (id == R.id.cnstrnt_digit_5) {
        callNativeEvent("5");
    } else if (id == R.id.cnstrnt_digit_6) {
        callNativeEvent("6");
    } else if (id == R.id.cnstrnt_digit_7) {
        callNativeEvent("7");
    } else if (id == R.id.cnstrnt_digit_8) {
        callNativeEvent("8");
    } else if (id == R.id.cnstrnt_digit_9) {
        callNativeEvent("9");
    } else if (id == R.id.cnstrnt_digit_star) {
        callNativeEvent("*");
    } else if (id == R.id.cnstrnt_digit_0) {
        callNativeEvent("0");
    } else if (id == R.id.cnstrnt_digit_pound) {
        callNativeEvent("#");
    }
}

    @Override
public boolean onLongClick(View view) {
    if (view.getId() == R.id.cnstrnt_digit_0) {
        callNativeEvent("+");
        return true;
    }
    return false;
}
}
