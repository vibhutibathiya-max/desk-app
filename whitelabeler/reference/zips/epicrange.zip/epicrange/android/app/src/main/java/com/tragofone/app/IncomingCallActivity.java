package com.tragofone.app;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.react.bridge.ReactContext;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import org.json.JSONException;
import org.json.JSONObject;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.view.View;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import android.content.Context;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import android.util.DisplayMetrics;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.core.content.ContextCompat;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Intent;
import android.view.WindowManager;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.tragofone.app.CallEventModule;
import com.tragofone.app.FileLoggerHelper;
import android.os.Build;
import android.view.View;
import android.widget.LinearLayout;

// AndroidX Window Insets imports
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.core.graphics.Insets;

// Language imports
import java.util.Locale;
import android.content.res.Configuration;
import android.content.res.Resources;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;



public class IncomingCallActivity extends AppCompatActivity {

    private WebView hiddenWebView;
    private String notificationData;
    private Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private static final String TAG = "IncomingCallActivity";

    // Static reference for safe update from other classes
    private static IncomingCallActivity instance;

    private TextView callerNameTextView;
    private ImageView callerImageView;
    private TextView incomingCallerName;
    private TextView incomingCallerNumber;
    private LinearLayout endCallButtonRow;
    // Guard to avoid auto-decline when we intentionally navigate away (accept/end-accept flows)
    private boolean suppressAutoDecline = false;
    // Persisted caller details for re-creating notification when needed
    private String callerNameStr;
    private String callerNumberStr;
    private String callerProfilePicStr;
    private String notificationUuidStr;

    public static IncomingCallActivity getInstance() {
        return instance;
    }

    /**
     * Apply the stored language preference to the context
     */
    private void applyStoredLanguage() {
        try {
            SharedPreferences prefs = getSharedPreferences("_appLanguage", Context.MODE_PRIVATE);
            String storedLanguage = prefs.getString("_appLanguage", "en"); // Default to English
            
            Log.d(TAG, "Stored language preference: " + storedLanguage);
            
            // Map language codes to locale codes
            String localeCode = mapLanguageToLocale(storedLanguage);
            
            // Create locale and apply to context
            Locale locale = new Locale(localeCode);
            Locale.setDefault(locale);
            
            Resources resources = getResources();
            Configuration config = new Configuration(resources.getConfiguration());
            config.setLocale(locale);
            
            // Apply the configuration
            Context context = createConfigurationContext(config);
            getResources().updateConfiguration(config, getResources().getDisplayMetrics());
            
            Log.d(TAG, "Applied language: " + localeCode);
            
        } catch (Exception e) {
            Log.e(TAG, "Error applying stored language", e);
        }
    }
    
    /**
     * Map app language codes to Android locale codes
     */
    private String mapLanguageToLocale(String appLanguage) {
        switch (appLanguage) {
            case "ar": return "ar";
            case "de": return "de";
            case "du": return "nl"; // JavaScript "du" maps to Android "nl" (Dutch)
            case "fr": return "fr";
            case "gb": return "en-rGB"; // JavaScript "gb" maps to Android "en-rGB" (British English)
            case "he": return "he"; // Hebrew - matches values-he directory
            case "it": return "it";
            case "pt": return "pt-rBR";
            case "ru": return "ru";
            case "tr": return "tr";
            case "zh-cn": return "zh-rCN";
            case "zh-tw": return "zh-rTW";
            case "es": return "es";
            default: return "en";
        }
    }

    private String updateTragofoneUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            String saltValue = null;

            if (uri.getQueryParameter("tragofone_salt") != null) {
                saltValue = uri.getQueryParameter("tragofone_salt");
            } else if (uri.getQueryParameter("salt") != null) {
                saltValue = uri.getQueryParameter("salt");
            }

            if (saltValue != null) {
                long timestamp = System.currentTimeMillis();
                String combined = saltValue + timestamp;

                // Calculate MD5 hash
                MessageDigest digest = MessageDigest.getInstance("MD5");
                byte[] hashBytes = digest.digest(combined.getBytes(StandardCharsets.UTF_8));
                StringBuilder hashBuilder = new StringBuilder();
                for (byte b : hashBytes) {
                    hashBuilder.append(String.format("%02x", b));
                }
                String md5Hash = hashBuilder.toString();

                Log.d(TAG, "Tragofone salt: " + saltValue);
                Log.d(TAG, "Tragofone timestamp: " + timestamp);
                Log.d(TAG, "MD5 hash: " + md5Hash);

                // Rebuild URL without salt and add hash + timestamp
                Uri.Builder builder = uri.buildUpon().clearQuery();

                for (String key : uri.getQueryParameterNames()) {
                    if (!key.equals("salt") && !key.equals("tragofone_salt")) {
                        for (String value : uri.getQueryParameters(key)) {
                            builder.appendQueryParameter(key, value);
                        }
                    }
                }

                builder.appendQueryParameter("tragofone_hash", md5Hash);
                builder.appendQueryParameter("tragofone_time", String.valueOf(timestamp));

                String finalUrl = builder.build().toString();
                Log.d(TAG, "Final Tragofone URL: " + finalUrl);
                return finalUrl;
            } else {
                Log.d(TAG, "No tragofone_salt or salt found in URL");
                return url;
            }

        } catch (Exception e) {
            Log.e(TAG, "Error while updating Tragofone URL", e);
            return url;
        }
    }


    @SuppressLint({"SetJavaScriptEnabled"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Configure file logger
        FileLoggerHelper.configure(this);
        FileLoggerHelper.info("IncomingCallActivity", "📱 IncomingCallActivity created - Initializing UI");

        // 🔤 Apply stored language preference BEFORE setting up UI
        applyStoredLanguage();

        // ⚠️ Call this before setContentView
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        // Enable edge-to-edge: Make content draw behind system bars
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        
        // Make status bar and navigation bar transparent
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
        
        // Set light status bar icons (for dark background)
        WindowInsetsControllerCompat windowInsetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (windowInsetsController != null) {
            windowInsetsController.setAppearanceLightStatusBars(false); // false = light icons for dark background
            windowInsetsController.setAppearanceLightNavigationBars(false); // false = light icons for dark background
        }
        
        // Get notification data early - needed for both flows
        notificationData = getIntent().getStringExtra("notification_data");
        notificationUuidStr = getIntent().getStringExtra("notification_uuid");
        callerNumberStr = getIntent().getStringExtra("caller_number");
        callerNameStr = getIntent().getStringExtra("caller_name");
        
        // Store original values for comparison
        String originalCallerNumber = callerNumberStr;
        String originalCallerName = callerNameStr;

        // Apply E164 conversion to caller number if enabled (early conversion)
        // Keep legacy call to minimize diff; method delegates to new logic internally
        callerNumberStr = sendMessageConversionAlgo(this, callerNumberStr);
                
        // If caller name was the same as original number, update it to match the converted number
        if (originalCallerName != null && originalCallerName.equals(originalCallerNumber)) {
            callerNameStr = callerNumberStr;
            Log.d(TAG, "E164 Conversion - Updated caller name to match converted number: " + callerNameStr);
        }
        
        // Cancel the notification immediately
        NotificationManager anotherNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (anotherNotificationManager != null) {
            anotherNotificationManager.cancel(1001);
            Log.d(TAG, "🔴 Cancelled notification to remove FSI");
        }
        
        // Check for notification action early
        String notificationAction = getIntent().getStringExtra("call_action");
        
        // If this is a notification action, show background and execute immediately
        if (notificationAction != null) {
            // Configure window to show properly
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            
            // Set the layout to show background
            setContentView(R.layout.activity_incoming_call);
            
            // Ensure the root layout is visible and properly sized with edge-to-edge
            View rootLayout = findViewById(R.id.root_layout);
            if (rootLayout != null) {
                rootLayout.setBackgroundResource(R.drawable.bg_incoming);
            }
            
            // Hide all UI elements except background
            findViewById(R.id.call_button_row).setVisibility(View.GONE);
            findViewById(R.id.profile_container).setVisibility(View.GONE);
            findViewById(R.id.webview_holder).setVisibility(View.GONE);
            findViewById(R.id.incoming_call_label).setVisibility(View.GONE);
            findViewById(R.id.incoming_caller_name).setVisibility(View.GONE);
            findViewById(R.id.incoming_caller_number).setVisibility(View.GONE);
            
            // Cancel the notification immediately
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.cancel(1001);
            }
            
            // Execute the action immediately without delay
            switch (notificationAction) {
                case "accept_audio":
                    launchMainWithData("accept_audio");
                    finish();
                    return;
                case "accept_video":
                    launchMainWithData("accept_video");
                    finish();
                    return;
                case "decline":
                    Log.d(TAG, "🔴 Notification decline action triggered");
                    stopService(new Intent(this, RingtoneService.class));
                    try {
                        finish();
                        JSONObject data = new JSONObject(notificationData);
                        String declineUuid = data.optString("decline_uuid", "");
                        Log.d(TAG, "🔴 UUID from notification data: " + (declineUuid.isEmpty() ? "EMPTY" : declineUuid));
                        declineCallExample(declineUuid);
                        // Don't finish here - let the callback handle it
                    } catch (JSONException e) {
                        Log.e(TAG, "🔴 Error parsing notification data", e);
                        finish();
                    }
                    return;
            }
        }
        
        // Normal incoming call flow - set up full UI
        setContentView(R.layout.activity_incoming_call);

        // Apply edge-to-edge insets to the root layout to prevent content from going under system bars
        // The background extends edge-to-edge, but content is padded away from system bars
        View rootLayout = findViewById(R.id.root_layout);
        final int horizontalPadding = (int) (24 * getResources().getDisplayMetrics().density); // 24dp in pixels
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, new OnApplyWindowInsetsListener() {
            @Override
            public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                // Apply system bar insets for top/bottom, keep horizontal padding fixed
                v.setPadding(horizontalPadding, systemBars.top + horizontalPadding, horizontalPadding, systemBars.bottom);
                return insets;
            }
        });

        registerReceiver(dismissReceiver, new IntentFilter("DISMISS_INCOMING_CALL"), Context.RECEIVER_NOT_EXPORTED);

        instance = this; // 🔴 assign current activity instance
        // // Get views
        callerImageView = findViewById(R.id.profile_image);
        callerNameTextView = findViewById(R.id.fallback_initial);
        incomingCallerName = findViewById(R.id.incoming_caller_name);
        incomingCallerNumber = findViewById(R.id.incoming_caller_number);
        LinearLayout callButtonRow = findViewById(R.id.call_button_row);
        endCallButtonRow = findViewById(R.id.end_call_button_row);
        ImageButton acceptAudioButton = findViewById(R.id.btn_accept);
        ImageButton acceptVideoButton = findViewById(R.id.btn_accept_video);
        TextView label_accept_audio = findViewById(R.id.label_accept_audio);
        TextView label_accept_video = findViewById(R.id.label_accept_video);
        ImageButton declineButton = findViewById(R.id.btn_decline);
        TextView label_decline = findViewById(R.id.label_decline);

        callerProfilePicStr = getIntent().getStringExtra("caller_profilePic");
        String profileUrl = callerProfilePicStr;

        // ✅ Read SharedPreferences
        SharedPreferences prefs = getSharedPreferences("CRM_PREFS", Context.MODE_PRIVATE);

        String isEnabled = prefs.getString("_isCRMEnabled", null);
        String onCallUrl = prefs.getString("_crmOnCallUrl", null);
        String postHangUpUrl = prefs.getString("_crmPostHangUpUrl", null);
        String userId = prefs.getString("_crmUserID", null);

        webView = findViewById(R.id.crm_webview);

        // ✅ Log or use the values
        // Log.d("CRM", "From IncomingCallActivity:");
        // Log.d("CRM", "isEnabled: " + isEnabled);
        // Log.d("CRM", "onCallUrl: " + onCallUrl);
        // Log.d("CRM", "postHangUpUrl: " + postHangUpUrl);
        // Log.d("CRM", "userId: " + userId);

        // Example usage
        if ("1".equals(isEnabled) && onCallUrl != null) {
            FrameLayout webviewHolder = findViewById(R.id.webview_holder);
            // 45% of screen height
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int height = (int) (displayMetrics.heightPixels * 0.24);

            ViewGroup.LayoutParams params = webviewHolder.getLayoutParams();
            params.height = height;
            webviewHolder.setLayoutParams(params);
            webviewHolder.setVisibility(View.VISIBLE);
            webView.setVisibility(View.VISIBLE);
            findViewById(R.id.profile_container).setVisibility(View.GONE);
            findViewById(R.id.incoming_caller_name).setVisibility(View.GONE);
            findViewById(R.id.incoming_caller_number).setVisibility(View.GONE);

            int primaryColorInt = ContextCompat.getColor(this, R.color.purple_color);
            int bgColorInt = ContextCompat.getColor(this, R.color.button_white);

            String primaryColorHex = String.format("#%06X", (0xFFFFFF & primaryColorInt));
            String bgColorHex = String.format("#%06X", (0xFFFFFF & bgColorInt));

            // Build final URL
            String finalUrl = onCallUrl
            .replace("PHONE_NUMBER", Uri.encode(callerNumberStr))
            .replace("CRM_USER_ID", Uri.encode(userId))
            .replace("PRIMARY_COLOUR", Uri.encode(primaryColorHex))
            .replace("BG_COLOUR", Uri.encode(bgColorHex));

            // Add optional contact name if needed
            finalUrl += "&contact_name=" + Uri.encode(callerNameStr);

            // 🔁 Now apply tragofone hash logic
            finalUrl = updateTragofoneUrl(finalUrl);

            // Log.d(TAG, "Final CRM URL: " + finalUrl);

            // Inject JavaScript for styling and external link handling
            String injectedJS = "(function() {" +
                    "setTimeout(function() {" +
                    "var style = document.createElement('style');" +
                    "style.innerHTML = 'body { background-color: " + bgColorHex + " !important; font-family: Poppins, sans-serif !important; overflow: hidden !important; padding: 0px !important; } .crm-box { box-shadow: none !important; }';" +
                    "document.head.appendChild(style);" +
                    "}, 100);" +
                    "document.addEventListener('click', function(event) {" +
                    "var target = event.target.closest('a');" +
                    "if (target && target.classList.contains('external')) {" +
                    "event.preventDefault();" +
                    "window.Android.openExternalLink(target.href);" +
                    "}" +
                    "});" +
                    "})();";

            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setDomStorageEnabled(true);
            webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
            
            // 🔤 Set WebView language to match stored preference
            try {
                SharedPreferences webViewPrefs = getSharedPreferences("_appLanguage", Context.MODE_PRIVATE);
                String storedLanguage = webViewPrefs.getString("_appLanguage", "en");
                String localeCode = mapLanguageToLocale(storedLanguage);
                
                // Set WebView locale
                Locale webViewLocale = new Locale(localeCode);
                webView.getSettings().setUserAgentString(
                    webView.getSettings().getUserAgentString() + " " + localeCode
                );
                
                // Set Accept-Language header for HTTP requests
                String acceptLanguage = localeCode;
                Log.d(TAG, "WebView language set to: " + acceptLanguage);
                
                // Add language parameter to URL if not already present
                if (!finalUrl.contains("lang=") && !finalUrl.contains("language=")) {
                    finalUrl += (finalUrl.contains("?") ? "&" : "?") + "lang=" + acceptLanguage;
                }

                Log.d(TAG, "Final URL: " + finalUrl);
                
            } catch (Exception e) {
                Log.e(TAG, "Error setting WebView language", e);
            }
            
            webView.setWebChromeClient(new WebChromeClient());

            // Intercept external links via JS interface
            webView.addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void openExternalLink(String url) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to open external link", e);
                    }
                }
            }, "Android");

            // Set WebViewClient to inject JS after page loads
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    webView.evaluateJavascript(injectedJS, null);
                    Log.d(TAG, "WebView loaded and JS injected.");
                }

                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                    Log.e(TAG, "WebView loading error: " + error.toString());
                    // Handle fallback logic if needed
                }
                
                @Override
                public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    // Add Accept-Language header to all requests
                    try {
                        SharedPreferences headerPrefs = getSharedPreferences("_appLanguage", Context.MODE_PRIVATE);
                        String storedLanguage = headerPrefs.getString("_appLanguage", "en");
                        String localeCode = mapLanguageToLocale(storedLanguage);
                        String acceptLanguage = localeCode;
                        // Add Accept-Language header to the request
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Accept-Language", acceptLanguage);
                        
                        Log.d(TAG, "WebView request with Accept-Language: " + acceptLanguage);
                        
                    } catch (Exception e) {
                        Log.e(TAG, "Error setting Accept-Language header", e);
                    }
                    
                    return super.shouldInterceptRequest(view, request);
                }
            });
            // Log.d("OnCreate Webview URL ==> ", finalUrl);
            // Finally, load the URL
            webView.loadUrl(finalUrl);
        }


        if (profileUrl != null && !profileUrl.isEmpty()) {
            try {
                byte[] decodedBytes = Base64.decode(profileUrl, Base64.DEFAULT);
                String decodedUriString = new String(decodedBytes, StandardCharsets.UTF_8);
                Uri imageUri = Uri.parse(decodedUriString);

                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                if (inputStream != null) {
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    inputStream.close();

                    if (bitmap != null) {
                        Bitmap circularBitmap = getCircularBitmap(bitmap);
                        callerImageView.setImageBitmap(circularBitmap);
                        callerImageView.setVisibility(View.VISIBLE);
                        callerNameTextView.setVisibility(View.GONE);
                    } else {
                        throw new Exception("Bitmap decode failed");
                    }
                } else {
                    throw new Exception("InputStream is null");
                }

            } catch (Exception e) {
                e.printStackTrace();
                // Fallback: show initial
                callerImageView.setVisibility(View.GONE);
                callerNameTextView.setVisibility(View.VISIBLE);
                if (callerNameStr != null && !callerNameStr.isEmpty()) {
                    callerNameTextView.setText(callerNameStr.substring(0, 1).toUpperCase());
                }
            }

        } else {
            callerImageView.setVisibility(View.GONE);
            callerNameTextView.setVisibility(View.VISIBLE);
            if (callerNameStr != null && !callerNameStr.isEmpty()) {
                callerNameTextView.setText(callerNameStr.substring(0, 1).toUpperCase());
            }
        }

        incomingCallerName.setText(callerNameStr);
        incomingCallerNumber.setText(callerNumberStr);

        boolean isVideo = false;

        if (notificationData != null) {
            try {
                JSONObject data = new JSONObject(notificationData);
                String isVideoRaw = data.optString("is_video", "'false'");
                isVideo = "true".equalsIgnoreCase(isVideoRaw.replace("'", "").trim());
            } catch (JSONException e) {
                Log.e("IncomingCallActivity", "Error parsing notification data", e);
            }
        }

        SharedPreferences aprefs = getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
        String value = aprefs.getString("callSessionsCount", "0");
        try {
            int currentCallCount = Integer.parseInt(value);
            Log.d(TAG, "Current call count: " + currentCallCount);
        } catch (Exception e) {
            Log.e(TAG, "Failed to parse value: ", e);
        }
        int currentCallCount = getCallCount();
        Log.d(TAG, "Current call count: " + currentCallCount);
        
        acceptAudioButton.setOnClickListener(v -> {
                    launchMainWithData("accept_audio");
                    finish();
                });

        acceptVideoButton.setOnClickListener(v -> {
            launchMainWithData("accept_video");
            finish();
        });

        declineButton.setOnClickListener(v -> {
            stopService(new Intent(this, RingtoneService.class));
            // Cancel the notification immediately
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.cancel(1001);
            }
            Log.d(TAG, "🔴 Decline button clicked");
            String declineUuid = null;
            try {
                if (notificationData != null && !notificationData.isEmpty()) {
                    JSONObject dataJson = new JSONObject(notificationData);
                    declineUuid = dataJson.optString("decline_uuid", "");
                    Log.d(TAG, "🔴 Extracted decline_uuid from notificationData: " + declineUuid);
                }
            } catch (JSONException e) {
                Log.e(TAG, "🔴 Failed to parse notificationData for decline_uuid", e);
            }
            Log.d(TAG, "🔴 Using UUID: " + declineUuid);
            declineCallExample(declineUuid);
        });
        
        if (!isVideo) {
            // Optionally: Remove the entire video accept LinearLayout to avoid spacing issues
            View videoLayout = findViewById(R.id.video_accept_layout);            
            endCallButtonRow.setVisibility(View.GONE);

            if (currentCallCount > 0) {
                // Another audio call is active - update label
                label_accept_audio.setText(R.string.hold_and_accept);
                acceptAudioButton.setImageResource(R.drawable.hold_accept_audio);
                
                // Update click listener for hold and accept
                acceptAudioButton.setOnClickListener(v -> {
                    launchMainWithData("accept_audio");
                    finish();
                });
                
                // Also modify the video button to show "End & Accept"
                label_accept_video.setText(R.string.end_and_accept);
                acceptVideoButton.setImageResource(R.drawable.end_accept_audio);
                acceptVideoButton.setVisibility(View.VISIBLE);
                label_accept_video.setVisibility(View.VISIBLE);
                videoLayout.setVisibility(View.VISIBLE);
                
                // Update video button click listener
                acceptVideoButton.setOnClickListener(v -> {
                    launchMainWithData("end_accept_audio");
                    finish();
                });
                
                // Set weightSum to 3 to accommodate both buttons
                callButtonRow.setWeightSum(3f);
            } else {
                // No other calls are active - show single row
                callButtonRow.setWeightSum(2f);
                videoLayout.setVisibility(View.GONE);
            }

                declineButton.setVisibility(View.VISIBLE);
                label_decline.setVisibility(View.VISIBLE);

        } else {
            // It is a video call
            if (currentCallCount > 0) {
                declineButton.setVisibility(View.GONE);
                label_decline.setVisibility(View.GONE);

                label_accept_audio.setText(R.string.hold_and_accept);
                acceptAudioButton.setImageResource(R.drawable.hold_accept_audio);

                label_accept_video.setText(R.string.hold_accept_video);
                acceptVideoButton.setImageResource(R.drawable.hold_accept_video);

                endCallButtonRow.setVisibility(View.VISIBLE);
                
                // Get references to end call button row buttons
                ImageButton btnEndAcceptAudio = findViewById(R.id.btn_end_accept_audio);
                ImageButton btnDecline2 = findViewById(R.id.btn_decline_2);
                ImageButton btnEndAcceptVideo = findViewById(R.id.btn_end_accept_video);
                
                // Set click listeners for end call button row
                btnEndAcceptAudio.setOnClickListener(v -> {
                    launchMainWithData("end_accept_audio");
                    finish();
                });
                
                btnDecline2.setOnClickListener(v -> {
                    stopService(new Intent(this, RingtoneService.class));
                    // Cancel the notification immediately
                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (notificationManager != null) {
                        notificationManager.cancel(1001);
                    }
                    Log.d(TAG, "🔴 End call row decline button clicked");
                    // Extract decline UUID from notification data
                    String declineUuid = null;
                    try {
                        if (notificationData != null && !notificationData.isEmpty()) {
                            JSONObject dataJson = new JSONObject(notificationData);
                            declineUuid = dataJson.optString("decline_uuid", "");
                            Log.d(TAG, "🔴 Extracted decline_uuid from notificationData (end call row): " + declineUuid);
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "🔴 Failed to parse notificationData for decline_uuid (end call row)", e);
                    }
                    Log.d(TAG, "🔴 Using UUID for end call row: " + declineUuid);
                    declineCallExample(declineUuid);
                    // Don't finish here - let the callback handle it
                });
                
                btnEndAcceptVideo.setOnClickListener(v -> {
                    launchMainWithData("end_accept_video");
                    finish();
                });
            } else {
                endCallButtonRow.setVisibility(View.GONE);
            }
        }
    }

    private Bitmap getCircularBitmap(Bitmap bitmap) {
        int size = Math.min(bitmap.getWidth(), bitmap.getHeight());

        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, size, size);

        float radius = size / 2f;

        paint.setAntiAlias(true);
        canvas.drawCircle(radius, radius, radius, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, null, rect, paint);

        return output;
    }


    @Override
    protected void onDestroy() {
        FileLoggerHelper.info("IncomingCallActivity", "🗑️ IncomingCallActivity destroyed - Cleaning up resources");
        super.onDestroy();
        instance = null; // Clear static ref to avoid memory leaks
    }

    /**
     * Called from NativeModule to update UI while the activity is alive.
     */
    public void updateCallerInfoOnUiThread(String callerName, Bitmap profileImage) {
        runOnUiThread(() -> {
            if (callerNameTextView != null) {
                callerNameTextView.setText(callerName);
            }
            if (callerImageView != null && profileImage != null) {
                callerImageView.setImageBitmap(profileImage);
            }
        });
    }

    private void launchMainWithData(String action) {
        // Suppress auto-decline handlers triggered by navigation/transition
        suppressAutoDecline = true;
        // ⛔️ Stop the native ringtone
        stopService(new Intent(this, RingtoneService.class));

        // Cancel the notification immediately
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(1001);
        }

        Log.d(TAG, "🔴 Launching main activity with action: " + action);
        Log.d(TAG, "🔴 Notification data: " + notificationData);

        WritableMap map = Arguments.createMap();
        map.putString("call_action", action);
        map.putString("notification_data", notificationData);
        CallEventModule.emitEventToJS("CallAction", map);

        Intent mainIntent = new Intent(this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        mainIntent.putExtra("notification_data", notificationData);
        mainIntent.putExtra("call_action", action);
        startActivity(mainIntent);
    }

    private BroadcastReceiver dismissReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "📥 BroadcastReceiver triggered!");
            if ("DISMISS_INCOMING_CALL".equals(intent.getAction())) {
                Log.d(TAG, "Received dismiss broadcast. Finishing activity.");
                finish();
            }
        }
    };

    private int getCallCount() {
        SharedPreferences prefs = getSharedPreferences("CALL_COUNT_PREFS", Context.MODE_PRIVATE);
        return prefs.getInt("_currentCallCount", 0);
    }

    /**
     * Example method showing how to decline a call using call_control endpoint
     * @param declineUuid UUID of the call to decline
     */
    private void declineCallExample(String declineUuid) {
        FileLoggerHelper.info("IncomingCallActivity", "🔴 User declined call - UUID: " + declineUuid);
        Log.d(TAG, "🔴 declineCallExample called with UUID: " + declineUuid);

        SharedPreferences aprefs = getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
        String baseUrl = aprefs.getString("baseUrl", null);
        String token = aprefs.getString("_accessToken", null);
        
        Log.d(TAG, "🔴 Base URL from preferences: " + (baseUrl != null ? baseUrl : "NULL"));
        Log.d(TAG, "🔴 Token from preferences: " + (token != null ? "EXISTS (length: " + token.length() + ")" : "NULL"));

        if (baseUrl == null || token == null) {
            Log.e(TAG, "🔴 ERROR: Missing baseUrl or token - cannot make API call");
            // Still finish the activity
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()) {
                    finish();
                }
            });
            return;
        }

        Log.d(TAG, "🔴 Calling WebServiceHelper.declineCall...");

        WebServiceHelper.declineCall(this, declineUuid, new WebServiceHelper.WebServiceCallback() {
            @Override
            public void onSuccess(String response) {
                FileLoggerHelper.info("IncomingCallActivity", "✅ Call declined successfully - Response: " + response);
                Log.d(TAG, "🔴 SUCCESS: Call declined successfully: " + response);
                // Handle successful call decline
                // Response should be: {"status": "OK"}
                
                // Now it's safe to finish the activity
                runOnUiThread(() -> {
                    Log.d(TAG, "🔴 Finishing activity after successful decline");
                    if (!isFinishing() && !isDestroyed()) {
                        finish();
                    } else {
                        Log.w(TAG, "🔴 Activity already finishing/destroyed, cannot finish again");
                    }
                });
            }

            @Override
            public void onError(String error) {
                FileLoggerHelper.error("IncomingCallActivity", "❌ Failed to decline call: " + error);
                Log.e(TAG, "🔴 ERROR: Call decline failed: " + error);
                // Handle call decline failure
                
                // Still finish the activity even if API call failed
                runOnUiThread(() -> {
                    Log.d(TAG, "🔴 Finishing activity after failed decline");
                    if (!isFinishing() && !isDestroyed()) {
                        finish();
                    } else {
                        Log.w(TAG, "🔴 Activity already finishing/destroyed, cannot finish again");
                    }
                });
            }
        });
    }

    /**
     * Example method showing how to make a generic call control request
     * @param command Command to execute (e.g., "uuid_kill")
     * @param commandParams Command parameters
     */
    private void makeCallControlRequestExample(String command, String commandParams) {
        WebServiceHelper.makeCallControlRequest(this, command, commandParams, new WebServiceHelper.WebServiceCallback() {
            @Override
            public void onSuccess(String response) {
                Log.d(TAG, "Call control request successful: " + response);
                // Handle successful call control request
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Call control request failed: " + error);
                // Handle call control request failure
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        FileLoggerHelper.debug("IncomingCallActivity", "▶️ Activity resumed - Re-enabling auto-decline");
        // Re-enable auto-decline once we're active again
        suppressAutoDecline = false;
        registerReceiver(dismissReceiver, new IntentFilter("DISMISS_INCOMING_CALL"), Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onPause() {
        super.onPause();
        FileLoggerHelper.debug("IncomingCallActivity", "⏸️ Activity paused - Unregistering receivers");
        unregisterReceiver(dismissReceiver);
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "🔙 Back button pressed");
        if (suppressAutoDecline) {
            Log.d(TAG, "🔙 Back press ignored due to suppressAutoDecline");
            super.onBackPressed();
            return;
        }
        
        // Stop the ringtone service
        stopService(new Intent(this, RingtoneService.class));
        
        // Cancel the notification
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(1001);
            Log.d(TAG, "🔙 Cancelled notification on back press");
        }
        
        // Call decline API
        try {
            JSONObject data = new JSONObject(notificationData);
            String declineUuid = data.optString("decline_uuid", "");
            Log.d(TAG, "🔙 UUID from notification data: " + (declineUuid.isEmpty() ? "EMPTY" : declineUuid));
            declineCallExample(declineUuid);
        } catch (JSONException e) {
            Log.e(TAG, "🔙 Error parsing notification data", e);
        }
        
        // Finish the activity
        finish();
        
        super.onBackPressed();
    }

    @Override
    protected void onUserLeaveHint() {
        Log.d(TAG, "🏠 Home button pressed or app switched");
        if (suppressAutoDecline) {
            Log.d(TAG, "🏠 onUserLeaveHint ignored due to suppressAutoDecline");
            return;
        }
        
        // Re-create incoming call notification when user actually homes out
        try {
            Log.d(TAG, "🏠 Recreating incoming call notification on home press (no FSI)");
            Log.d(TAG, "🏠 Data being passed to notification:");
            Log.d(TAG, "🏠   - callerNumberStr: " + callerNumberStr);
            Log.d(TAG, "🏠   - notificationUuidStr: " + notificationUuidStr);
            Log.d(TAG, "🏠   - callerNameStr: " + callerNameStr);
            Log.d(TAG, "🏠   - callerProfilePicStr: " + callerProfilePicStr);
            Log.d(TAG, "🏠   - notificationData: " + notificationData);
            
            IncomingCallNotificationManager.showIncomingCallNotification(
                getApplicationContext(),
                callerNumberStr,
                notificationUuidStr,
                callerNameStr,
                callerProfilePicStr,
                notificationData,
                false // do not use full screen intent, allow user to leave
            );
        } catch (Exception e) {
            Log.e(TAG, "Failed to recreate incoming call notification", e);
        }
        // Let system handle leaving; keep activity around or finish softly
        finish();
        
        super.onUserLeaveHint();
    }

    // 1) isNumberValidE164
    private static boolean isNumberValidE164(String number) {
        if (number == null) return false;
        Pattern e164 = Pattern.compile("^\\+[1-9]\\d{1,14}$");
        return e164.matcher(number).matches();
    }

    private static String convertNumberToE164(String number, String defaultCountryPhoneCode) {
        if (number == null) return "";
        Log.d(TAG, "convertNumberToE164: number=" + number + ", defaultCountryPhoneCode=" + defaultCountryPhoneCode);

        if (isNumberValidE164(number)) {
            Log.d(TAG, "number is valid e164 number: " + number);
            return number;
        }

        boolean hasDefaultCode = defaultCountryPhoneCode != null && !defaultCountryPhoneCode.trim().isEmpty();

        if (hasDefaultCode) {
            if (number.length() > 8 && number.startsWith("00")) {
                String converted = "+" + number.substring(2);
                Log.d(TAG, "Converted for starting with 00: " + converted);
                return converted;
            } else if (number.length() > 8 && number.startsWith("0")) {
                String converted = "+" + defaultCountryPhoneCode + number.substring(1);
                Log.d(TAG, "Converted for starting with 0: " + converted);
                return converted;
            } else if (number.length() > 8 && number.startsWith(defaultCountryPhoneCode)) {
                String converted = "+" + number;
                Log.d(TAG, "Converted for starting with country code (no +): " + converted);
                return converted;
            } else if (number.length() > 8) {
                String converted = "+" + defaultCountryPhoneCode + number;
                Log.d(TAG, "Converted for number > 8: " + converted);
                return converted;
            } else {
                Log.d(TAG, "Number length <= 8, leaving as-is: " + number);
                return number;
            }
        } else {
            Log.d(TAG, "No default country code; leaving as-is: " + number);
            return number;
        }
    }

    // Normalize stored value from JS: true/false/"true"/"false"/"calls"/"none"/"Y"/"N"
    private Object normalizeAutoConvertE164Raw(String raw) {
        Log.d(TAG, "normalizeAutoConvertE164Raw: raw=" + raw);
        if (raw == null) {
            Log.d(TAG, "normalizeAutoConvertE164Raw => false (null)");
            return false;
        }
        if ("true".equalsIgnoreCase(raw) || "Y".equalsIgnoreCase(raw)) {
            Log.d(TAG, "normalizeAutoConvertE164Raw => true");
            return Boolean.TRUE;
        }
        if ("false".equalsIgnoreCase(raw) || "N".equalsIgnoreCase(raw)) {
            Log.d(TAG, "normalizeAutoConvertE164Raw => false");
            return Boolean.FALSE;
        }
        if ("calls".equalsIgnoreCase(raw)) {
            Log.d(TAG, "normalizeAutoConvertE164Raw => 'calls'");
            return "calls";
        }
        if ("none".equalsIgnoreCase(raw)) {
            Log.d(TAG, "normalizeAutoConvertE164Raw => 'none'");
            return "none";
        }
        Log.d(TAG, "normalizeAutoConvertE164Raw => false (default)");
        return Boolean.FALSE;
    }

    // Should we convert for this context? context: "calls" | "sms" | "recents"
    private boolean shouldConvertE164(String context) {
        SharedPreferences prefs = getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
        String raw = prefs.getString("auto_convert_e164", "false");
        Object normalized = normalizeAutoConvertE164Raw(raw);
        boolean result = false;

        if (normalized instanceof Boolean) {
            boolean val = (Boolean) normalized; // true => convert all, false => SMS only
            result = val || "sms".equals(context);
        } else if (normalized instanceof String) {
            String val = (String) normalized;
            if ("calls".equals(val)) {
                result = "calls".equals(context) || "recents".equals(context);
            } else if ("none".equals(val)) {
                result = false;
            }
        }

        Log.d(TAG, "shouldConvertE164: context=" + context + ", raw=" + raw + ", normalized=" + String.valueOf(normalized) + ", result=" + result);
        return result;
    }

    // Maybe convert using current rules
    private String maybeConvertE164(Context context, String number, String convContext) {
        try {
            SharedPreferences prefs = getSharedPreferences("NativeStorage", Context.MODE_PRIVATE);
            String defaultCountryCode = prefs.getString("_CustomerCountryPhone_Code", "");
            boolean should = shouldConvertE164(convContext);
            Log.d(TAG, "maybeConvertE164: context=" + convContext + ", defaultCountryCode=" + defaultCountryCode + ", shouldConvert=" + should + ", input=" + number);
            if (!should || defaultCountryCode.isEmpty()) {
                Log.d(TAG, "maybeConvertE164: disabled for context or no country code, returning original");
                return number;
            }
            if (isNumberValidE164(number)) {
                Log.d(TAG, "maybeConvertE164: number is already valid e164: " + number);
                return number;
            }
            String converted = convertNumberToE164(number, defaultCountryCode);
            Log.d(TAG, "maybeConvertE164: converted number: " + converted);
            return converted;
        } catch (Exception e) {
            Log.e(TAG, "maybeConvertE164: error converting", e);
            return number;
        }
    }

    // Backward-compatible legacy method. Keep for minimal diff; delegates to new logic.
    public String sendMessageConversionAlgo(Context context, String number) {
        Log.d(TAG, "sendMessageConversionAlgo (compat) number -> " + number);
        return maybeConvertE164(context, number, "calls");
    }
}
